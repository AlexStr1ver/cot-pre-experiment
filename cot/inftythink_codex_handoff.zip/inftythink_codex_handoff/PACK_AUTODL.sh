#!/usr/bin/env bash
# Package the current AutoDL project without running inference or changing results.
set -euo pipefail
task_base="${1:-/root/autodl-tmp}"
cd "$task_base"
task_python="$task_base/venvs/infty-official/bin/python"
if [[ ! -x "$task_python" ]]; then task_python=python; fi
task_meta=$(mktemp -d "$task_base/inftythink_handoff_meta.XXXXXX")
"$task_python" - <<'PY' > "$task_meta/environment.json"
import sys, json, platform, importlib.metadata
report = {"python": sys.executable, "python_version": sys.version,
          "platform": platform.platform()}
for name in ["torch", "transformers", "vllm", "huggingface_hub", "accelerate"]:
    try:
        report[name] = importlib.metadata.version(name)
    except importlib.metadata.PackageNotFoundError:
        report[name] = "NOT_INSTALLED"
print(json.dumps(report, ensure_ascii=False, indent=2))
PY
nvidia-smi > "$task_meta/nvidia-smi.txt" 2>&1 || true
task_paths=("$(basename "$task_meta")")
for task_dir in inftythink_day1 inftythink_official_check infty_branch_pilot infty_sampling_check outputs InftyThink InftyThink-Plus; do
    if [[ -d "$task_dir" ]]; then
        task_paths+=("$task_dir")
    else
        printf 'Not found: %s\n' "$task_base/$task_dir" >> "$task_meta/missing_paths.txt"
    fi
done
if [[ ${#task_paths[@]} -eq 1 ]]; then
    printf 'No project directory found under %s\n' "$task_base" >&2
    exit 1
fi
task_archive="$task_base/inftythink_autodl_handoff_$(date -u +%Y%m%dT%H%M%SZ)_$$.tar.gz"
tar --exclude='*.safetensors' --exclude='*.bin' --exclude='*.pt' \
    --exclude='*.pth' --exclude='*.ckpt' --exclude='*.gguf' --exclude='*.onnx' \
    --exclude='__pycache__' --exclude='.git' --exclude='.cache' \
    --exclude='hf-cache' --exclude='venvs' --exclude='venv' --exclude='.venv' \
    --exclude='.env' --exclude='.env.*' \
    -czf "$task_archive" "${task_paths[@]}"
sha256sum "$task_archive"
printf 'PACK_OK: %s\n' "$task_archive"
