#!/usr/bin/env python3
"""Small native-summary diagnostic using the validated vLLM prompt and parser.

This is our batch wrapper around the official example's iteration mechanism,
not an unchanged official benchmark runner. No forced summary or signal policy.
"""
from __future__ import annotations

import argparse
from collections import Counter
import csv
import hashlib
import importlib.metadata
import json
from pathlib import Path
import re
import runpy
import shutil
import sys
import time


MODEL_SHA = "2ffdd84494667fbba35525550f9396492b264e23"
DATA_SHA = "6e4ed1a2a79af7d8630a6b768ec859cb5af4d3be"
BASE = Path("/root/autodl-tmp/inftythink_day1")


def write_json(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def last_boxed(text):
    for match in reversed(list(re.finditer(r"\\boxed\s*\{", text))):
        depth = 1
        for i in range(match.end(), len(text)):
            depth += (text[i] == "{") - (text[i] == "}")
            if depth == 0:
                return text[match.end():i].strip()
    return None


def run_case(model, tok, item, index, args, reset_prompt, output, sampling_class):
    base = tok.apply_chat_template(
        [{"role": "user", "content": item["problem"]}],
        tokenize=False, add_generation_prompt=True,
    )
    prompt = base + "<think>\n"
    record = {
        "case": index + 1, "unique_id": item["unique_id"],
        "problem": item["problem"], "reference_answer": item["answer"],
        "status": "running", "completed": False, "rounds": [],
        "pred_boxed": None,
    }
    case_json = output / "cases" / f"{index + 1:03d}.json"
    with (output / "cases" / f"{index + 1:03d}.txt").open("w", encoding="utf-8") as log:
        write_json(case_json, record)
        for epoch in range(args.max_rounds):
            ids = tok.encode(prompt, add_special_tokens=False)
            assert ids[0] == tok.bos_token_id and ids[1] != tok.bos_token_id, "BOS mismatch"
            request_seed = args.seed + index * 1000 + epoch
            params = sampling_class(
                n=1, max_tokens=args.round_tokens, temperature=0.7, top_p=0.95,
                skip_special_tokens=False, seed=request_seed,
            )
            print(f"CASE {index + 1}/{args.limit} ROUND {epoch + 1}: generating", flush=True)
            log.write(f"===== Iteration {epoch} =====\nINPUT\n{prompt}\n")
            log.flush()
            started = time.perf_counter()
            result = model.generate({"prompt_token_ids": ids}, params)[0].outputs[0]
            elapsed = time.perf_counter() - started
            text = result.text
            event = {
                "iteration": epoch, "seed": request_seed,
                "prompt": prompt, "input_token_ids": ids,
                "text": text, "generated_token_ids": list(result.token_ids),
                "input_tokens": len(ids), "generated_tokens": len(result.token_ids),
                "finish_reason": result.finish_reason, "stop_reason": result.stop_reason,
                "generation_seconds": elapsed, "summary": None, "reset_ok": None,
            }
            record["rounds"].append(event)
            log.write(f"OUTPUT\n{text}\n")
            log.write("ROUND_META " + json.dumps({
                k: event[k] for k in ("seed", "input_tokens", "generated_tokens", "finish_reason", "stop_reason", "generation_seconds")
            }, ensure_ascii=False) + "\n")
            if "<summary>" not in text:
                if result.finish_reason == "length":
                    record["status"] = "round_token_limit"
                elif "</think>" in text and text.rsplit("</think>", 1)[1].strip():
                    record["status"] = "final_output_review_required"
                    record["final_text"] = text.rsplit("</think>", 1)[1].strip()
                    record["pred_boxed"] = last_boxed(record["final_text"])
                else:
                    record["status"] = "stopped_without_final_text"
                write_json(case_json, record)
                break
            summaries = re.findall(r"<summary>\s*(.*?)\s*</summary>", text, re.S)
            if not summaries or not summaries[-1].strip():
                record["status"] = "invalid_or_truncated_summary"
                write_json(case_json, record)
                break
            event["summary"] = summaries[-1].strip()
            new_prompt = reset_prompt(prompt + text)
            history = re.fullmatch(re.escape(base) + r"<history>(.*?)</history>", new_prompt, re.S)
            event["reset_ok"] = bool(history and history.group(1).strip() == event["summary"])
            log.write(f"RESET_CHECK {event['reset_ok']}\n")
            if not event["reset_ok"]:
                record["status"] = "invalid_summary_reset"
                write_json(case_json, record)
                break
            prompt = new_prompt + "<think>\n"
            write_json(case_json, record)
        else:
            record["status"] = "iteration_limit"
        record["completed"] = True  # Diagnostic record finished; correctness is still ungraded.
        record["generated_tokens_total"] = sum(r["generated_tokens"] for r in record["rounds"])
        record["generation_seconds_total"] = sum(r["generation_seconds"] for r in record["rounds"])
        record["native_summary_outputs"] = sum(r["summary"] is not None for r in record["rounds"])
        record["executed_summary_restarts"] = sum(r["reset_ok"] is True for r in record["rounds"][:-1])
        log.write(f"FINAL_STATUS {record['status']}\n")
        write_json(case_json, record)
    print(json.dumps({k: record[k] for k in (
        "case", "unique_id", "status", "pred_boxed", "native_summary_outputs",
        "executed_summary_restarts", "generated_tokens_total",
    )}, ensure_ascii=False), flush=True)
    return record


def report(output, items):
    records = []
    for i, item in enumerate(items):
        p = output / "cases" / f"{i + 1:03d}.json"
        if p.exists():
            r = json.loads(p.read_text())
            if r.get("completed") and r["unique_id"] == item["unique_id"]:
                records.append(r)
    reviewed = {}
    review_path = output / "review.csv"
    if review_path.exists():
        with review_path.open(newline="", encoding="utf-8-sig") as f:
            reviewed = {r["unique_id"]: r for r in csv.DictReader(f)}
    fields = ["case", "unique_id", "status", "pred_boxed", "reference_answer", "native_summary_outputs", "executed_summary_restarts", "manual_correct", "notes"]
    with review_path.open("w", newline="", encoding="utf-8-sig") as f:
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader()
        for r in records:
            row = {k: r.get(k, "") for k in fields}
            row.update({k: reviewed.get(r["unique_id"], {}).get(k, "") for k in ("manual_correct", "notes")})
            writer.writerow(row)
    summary = {
        "n": len(records), "requested": len(items),
        "status_counts": dict(Counter(r["status"] for r in records)),
        "native_summary_outputs": sum(r["native_summary_outputs"] for r in records),
        "executed_summary_restarts": sum(r["executed_summary_restarts"] for r in records),
        "cases_with_native_summary": sum(r["native_summary_outputs"] > 0 for r in records),
        "generated_tokens_total": sum(r["generated_tokens_total"] for r in records),
        "generation_seconds_total": sum(r["generation_seconds_total"] for r in records),
        "accuracy": None,
        "note": "Manual math grading required. Generation timings exclude engine initialization and are diagnostic; no paper speedup claim.",
    }
    write_json(output / "summary.json", summary)
    return summary


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--model", type=Path, default=BASE / "models/InftyThink-1.5B")
    parser.add_argument("--data", type=Path, default=BASE / "data/day1_20.jsonl")
    parser.add_argument("--manifest", type=Path, default=BASE / "manifest.json")
    parser.add_argument("--reference-runner", type=Path, default=Path(__file__).resolve().with_name("infer_single_checkpoint.py"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--limit", type=int, default=5)
    parser.add_argument("--round-tokens", type=int, default=8192)
    parser.add_argument("--max-rounds", type=int, default=3)
    parser.add_argument("--seed", type=int, default=2026)
    parser.add_argument("--resume", action="store_true")
    args = parser.parse_args()
    assert 1 <= args.limit <= 20 and args.round_tokens > 0 and args.max_rounds > 0
    for p in (args.data, args.manifest, args.reference_runner, args.model / "config.json"):
        assert p.is_file(), f"Missing file: {p}"
    assert list(args.model.glob("*.safetensors")), "Missing weights"
    manifest = json.loads(args.manifest.read_text())
    assert manifest["model_revision"] == MODEL_SHA, "Unexpected model revision"
    assert manifest["dataset_revision"] == DATA_SHA, "Unexpected dataset revision"
    data = [json.loads(line) for line in args.data.read_text().splitlines() if line.strip()]
    assert [r["unique_id"] for r in data] == manifest["day1_ids"], "Development sample order mismatch"
    items = data[:args.limit]
    for item in items:
        assert all(k in item for k in ("unique_id", "problem", "answer"))
    reference = runpy.run_path(str(args.reference_runner))
    reset_prompt = reference["inf_thought_process_prompts"]
    config = {
        "model": str(args.model.resolve()), "model_revision": MODEL_SHA,
        "dataset_revision": DATA_SHA, "data_sha256": digest(args.data),
        "reference_runner_sha256": digest(args.reference_runner), "script_sha256": digest(Path(__file__)),
        "seed": args.seed, "request_seed_rule": "seed + zero_based_case_index * 1000 + zero_based_round_index",
        "dtype": "bfloat16", "round_tokens": args.round_tokens, "max_rounds": args.max_rounds,
        "temperature": 0.7, "top_p": 0.95, "prompt": "checkpoint chat template plus <think> newline",
        "forced_summary": False, "accuracy_grading": "manual",
    }
    out = args.output.resolve()
    if out.exists() and any(out.iterdir()):
        assert args.resume, f"Output exists: {out}. Use --resume to preserve and continue it."
        assert json.loads((out / "run_config.json").read_text()) == config, "Resume configuration mismatch"
    out.mkdir(parents=True, exist_ok=True)
    (out / "cases").mkdir(exist_ok=True)
    write_json(out / "run_config.json", config)
    shutil.copyfile(args.reference_runner, out / "reference_runner.py")
    shutil.copyfile(Path(__file__), out / "native_batch_check.py")
    pending = []
    for i, item in enumerate(items):
        p = out / "cases" / f"{i + 1:03d}.json"
        if args.resume and p.exists():
            r = json.loads(p.read_text())
            if r.get("completed") and r["unique_id"] == item["unique_id"]:
                print(f"REUSE case {i + 1}: {r['status']}", flush=True)
                continue
        pending.append((i, item))
    if pending:
        from transformers import AutoTokenizer
        import torch
        import vllm
        assert torch.cuda.is_available() and torch.cuda.is_bf16_supported()
        tok = AutoTokenizer.from_pretrained(str(args.model), local_files_only=True)
        for marker in ("<think>", "</think>", "<summary>", "</summary>", "<history>", "</history>"):
            assert len(tok.encode(marker, add_special_tokens=False)) == 1, marker
        write_json(out / "environment.json", {
            "python": sys.executable, "gpu": torch.cuda.get_device_name(0),
            "torch": torch.__version__, "cuda": torch.version.cuda,
            "transformers": importlib.metadata.version("transformers"), "vllm": vllm.__version__,
        })
        print("PREFLIGHT_OK; loading the model once.", flush=True)
        model = vllm.LLM(str(args.model), tensor_parallel_size=1, dtype="bfloat16", seed=args.seed)
        try:
            for i, item in pending:
                run_case(model, tok, item, i, args, reset_prompt, out, vllm.SamplingParams)
        finally:
            print(json.dumps(report(out, items), ensure_ascii=False, indent=2), flush=True)
    else:
        print(json.dumps(report(out, items), ensure_ascii=False, indent=2), flush=True)


if __name__ == "__main__":
    main()
