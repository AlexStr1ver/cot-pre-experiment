import re

PROMPT_PREFIX = "User:"
PROMPT_SUFFIX = "Assistant:"


MAX_EPOCHS = 3

def inf_thought_check_completion_status(completion) -> bool:
    return '<summary>' not in completion


def inf_thought_process_prompts(prompt) -> str:
    if '<summary>' not in prompt:
        return prompt
    else:
        try:
            instruction, think, summary = re.search(r'(.+)<think>\n(.+)\n</think>\s*<summary>\n(.+)\n</summary>', prompt, re.S).groups()
            if '<history>' in instruction:
                instruction = re.sub(r'<history>.+</history>', '', instruction, flags=re.S)
            return instruction + '<history>' + summary + '</history>'
        except Exception:
            if '<think>' not in prompt:
                return prompt
            else:
                instruction, think = re.search(r'(.+)<think>\n(.+)', prompt, re.S).groups()
                return instruction


if __name__ == '__main__':
    import vllm
    import json, time
    from transformers import AutoTokenizer

    model_path = '/root/autodl-tmp/inftythink_day1/models/InftyThink-1.5B'
    question = 'Find the number of quadratic equations of the form $x^2 + ax + b = 0,$ such that whenever $c$ is a root of the equation, $c^2 - 2$ is also a root of the equation.'
    tokenizer = AutoTokenizer.from_pretrained(model_path, local_files_only=True)
    base_prompt = tokenizer.apply_chat_template(
        [{"role": "user", "content": question}],
        tokenize=False, add_generation_prompt=True,
    )
    prompt = base_prompt + "<think>\n"

    model = vllm.LLM(model_path, tensor_parallel_size=1, dtype="bfloat16", seed=2026)
    sampling_params = vllm.SamplingParams(n=1, max_tokens=8192, temperature=0.7, top_p=0.95, skip_special_tokens=False)

    for epoch in range(MAX_EPOCHS):
        print(f"===== Iteration {epoch} =====\n\n")
        print("Start of input text >>>>> \n")
        print(prompt)
        print("<<<<< End of input text\n\n")

        ids = tokenizer.encode(prompt, add_special_tokens=False)
        assert ids[0] == tokenizer.bos_token_id
        assert ids[1] != tokenizer.bos_token_id, "Duplicated BOS"
        started = time.perf_counter()
        result = model.generate({"prompt_token_ids": ids}, sampling_params)[0].outputs[0]
        seconds = time.perf_counter() - started
        generated_text = result.text
        print("ROUND_META", json.dumps({
            "iteration": epoch,
            "input_tokens": len(ids),
            "generated_tokens": len(result.token_ids),
            "finish_reason": result.finish_reason,
            "stop_reason": result.stop_reason,
            "seconds": round(seconds, 3),
        }, ensure_ascii=False))
        print("Start of output text >>>>> \n")
        print(generated_text)
        print("<<<<< End of output text\n\n")


        if inf_thought_check_completion_status(generated_text):
            status = "ROUND_TOKEN_LIMIT" if result.finish_reason == "length" else "FINAL_OUTPUT_REVIEW_REQUIRED"
            print("FINAL_STATUS", status)
            break
        prompt += generated_text
        new_prompt = inf_thought_process_prompts(prompt)
        history = re.fullmatch(re.escape(base_prompt) + r"<history>(.*?)</history>", new_prompt, re.S)
        summaries = re.findall(r"<summary>\s*(.*?)\s*</summary>", generated_text, re.S)
        reset_ok = bool(
            history and summaries and summaries[-1].strip()
            and history.group(1).strip() == summaries[-1].strip()
        )
        print("RESET_CHECK", reset_ok)
        if not reset_ok:
            print("FINAL_STATUS", "INVALID_SUMMARY_OR_RESET")
            break
        prompt = new_prompt + "<think>\n"


    else:
        print("FINAL_STATUS", "ITERATION_LIMIT")
