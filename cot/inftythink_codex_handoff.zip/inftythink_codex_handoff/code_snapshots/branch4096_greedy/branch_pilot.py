#!/usr/bin/env python3
"""Training-free counterfactual pilot from saved native reasoning prefixes.

A: continue. B: force one summary, reset, continue. C: short answer probe.
All new continuations are greedy; sampled native20 outcomes are descriptive only.
The baseline, model weights, and original scripts are never modified.
"""
from __future__ import annotations

import argparse
from collections import Counter
import csv
import hashlib
import importlib.metadata
import json
import math
from pathlib import Path
import re
import runpy
import shutil
import sys
import time

MODEL_SHA = "2ffdd84494667fbba35525550f9396492b264e23"


def dump(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def first_boxed(text):
    match = re.search(r"\\boxed\s*\{", text)
    if not match:
        return None
    depth = 1
    for i in range(match.end(), len(text)):
        depth += (text[i] == "{") - (text[i] == "}")
        if depth == 0:
            return text[match.end():i].strip(), i + 1
    return None


def last_boxed(text):
    for match in reversed(list(re.finditer(r"\\boxed\s*\{", text))):
        found = first_boxed(text[match.start():])
        if found:
            return found[0]
    return None


def choose_candidates(records, tok, start, window):
    end_markers = {tok.convert_tokens_to_ids(t) for t in ("</think>", "<summary>", "</summary>")}
    end_markers.add(tok.eos_token_id)
    candidates, skipped = [], []
    for record in records:
        first = record["rounds"][0]
        generated = first["generated_token_ids"]
        boundary = next((i for i, token in enumerate(generated) if token in end_markers), len(generated))
        if boundary < start:
            skipped.append({"case": record["case"], "reason": "thinking_ended_before_target"})
            continue
        cut = next((i for i in range(start, min(boundary, start + window) + 1)
                    if tok.decode(generated[:i], skip_special_tokens=False).endswith("\n\n")), None)
        if cut is None:
            skipped.append({"case": record["case"], "reason": "no_paragraph_boundary_in_window"})
            continue
        prefix_ids = first["input_token_ids"] + generated[:cut]
        prefix_text = tok.decode(prefix_ids, skip_special_tokens=False)
        base = first["prompt"].split("<think>", 1)[0]
        assert prefix_text.startswith(base + "<think>\n")
        assert prefix_ids.count(tok.bos_token_id) == 1
        candidates.append({
            "case": record["case"], "unique_id": record["unique_id"],
            "contains_asy": "[asy]" in record["problem"],
            "cut": cut, "prefix_token_ids": prefix_ids, "prefix_text": prefix_text,
            "base_prompt": base, "reference_answer": record["reference_answer"],
            "original_native_answer": record.get("pred_boxed"),
        })
    return candidates, skipped


class Pilot:
    def __init__(self, model, tok, sampling_class, native_reset, args, output):
        self.model, self.tok, self.sampling = model, tok, sampling_class
        self.native_reset, self.args, self.output = native_reset, args, output

    def save(self, record):
        stem = f"{record['case']:03d}_{record['branch']}"
        dump(self.output / "branches" / (stem + ".json"), record)
        with (self.output / "branches" / (stem + ".txt")).open("w", encoding="utf-8") as f:
            f.write(f"CASE {record['case']} BRANCH {record['branch']} CUT {record['cut']}\n")
            for i, event in enumerate(record["calls"]):
                f.write(f"\n===== CALL {i + 1}: {event['kind']} =====\nINPUT\n{event['prompt']}\n")
                f.write(f"OUTPUT\n{event['text']}\n")
                f.write("META " + json.dumps({k: event[k] for k in (
                    "input_tokens", "generated_tokens", "finish_reason", "stop_reason", "seconds"
                )}) + "\n")
            f.write(f"\nSTATUS {record['status']}\nPRED_BOXED {record.get('pred_boxed')}\n")

    def call(self, record, ids, cap, kind, summary_stop=False, logprobs=False):
        assert cap > 0
        assert ids[0] == self.tok.bos_token_id and ids[1] != self.tok.bos_token_id
        stop_ids = [self.tok.convert_tokens_to_ids("</summary>")] if summary_stop else None
        params = self.sampling(
            n=1, max_tokens=cap, temperature=0.0, top_p=1.0,
            skip_special_tokens=False, stop_token_ids=stop_ids,
            include_stop_str_in_output=True, logprobs=1 if logprobs else None,
        )
        print(f"CASE {record['case']} {record['branch']}: {kind}, cap={cap}", flush=True)
        started = time.perf_counter()
        result = self.model.generate({"prompt_token_ids": ids}, params)[0].outputs[0]
        elapsed = time.perf_counter() - started
        new_ids = list(result.token_ids)
        text = self.tok.decode(new_ids, skip_special_tokens=False)
        probabilities = None
        if logprobs:
            probabilities = []
            for i, token in enumerate(new_ids):
                entries = result.logprobs[i] if result.logprobs and i < len(result.logprobs) else None
                entry = entries.get(token) if entries else None
                value = getattr(entry, "logprob", None)
                probabilities.append(math.exp(float(value)) if value is not None else None)
        event = {
            "kind": kind, "prompt": self.tok.decode(ids, skip_special_tokens=False),
            "input_token_ids": ids, "input_tokens": len(ids),
            "text": text, "engine_text": result.text,
            "generated_token_ids": new_ids, "generated_tokens": len(new_ids),
            "finish_reason": result.finish_reason, "stop_reason": result.stop_reason,
            "seconds": elapsed, "selected_token_probabilities": probabilities,
        }
        record["calls"].append(event)
        self.save(record)
        return event

    def reasoning(self, record, candidate, prompt_ids, first_cap, start_segment):
        for segment in range(start_segment, self.args.max_segments):
            remaining = record["generation_budget"] - sum(c["generated_tokens"] for c in record["calls"])
            if remaining <= 0:
                record["status"] = "generation_budget_limit"
                return
            cap = min(first_cap if segment == start_segment else self.args.round_tokens, remaining)
            event = self.call(record, prompt_ids, cap, "continue_reasoning")
            text = event["text"]
            if "<summary>" in text:
                summaries = re.findall(r"<summary>\s*(.*?)\s*</summary>", text, re.S)
                if not summaries or not summaries[-1].strip():
                    record["status"] = "invalid_or_truncated_native_summary"
                    return
                new_prompt = self.native_reset(event["prompt"] + text)
                history = re.fullmatch(re.escape(candidate["base_prompt"]) + r"<history>(.*?)</history>", new_prompt, re.S)
                event["summary"] = summaries[-1].strip()
                event["reset_ok"] = bool(history and history.group(1).strip() == event["summary"])
                if not event["reset_ok"]:
                    record["status"] = "invalid_native_reset"
                    return
                prompt_ids = self.tok.encode(new_prompt + "<think>\n", add_special_tokens=False)
                continue
            if event["finish_reason"] == "length":
                record["status"] = "reasoning_token_limit"
                return
            # EOS is not itself proof of a complete final answer.
            final = text.rsplit("</think>", 1)[-1] if "</think>" in text else ""
            final = final.replace(self.tok.eos_token or "", "").strip()
            if not final:
                record["status"] = "stopped_without_final_text"
                return
            record["final_text"] = final
            record["pred_boxed"] = last_boxed(final)
            record["status"] = "final_output_review_required"
            return
        record["status"] = "segment_limit"

    def run(self, candidate, branch):
        prefix_ids = candidate["prefix_token_ids"]
        record = {
            "case": candidate["case"], "unique_id": candidate["unique_id"],
            "branch": branch, "cut": candidate["cut"],
            "reference_answer": candidate["reference_answer"],
            "status": "running", "record_finished": False, "pred_boxed": None,
            "generation_budget": self.args.total_tokens - candidate["cut"],
            "probe_confidence": None, "calls": [],
        }
        self.save(record)
        if branch == "A_continue":
            self.reasoning(record, candidate, prefix_ids,
                           self.args.round_tokens - candidate["cut"], 0)
        elif branch == "B_summary":
            suffix_ids = self.tok.encode("\n</think><summary>\n", add_special_tokens=False)
            record["inserted_control_tokens"] = len(suffix_ids)
            event = self.call(record, prefix_ids + suffix_ids,
                              min(self.args.summary_tokens, record["generation_budget"]),
                              "forced_summary", summary_stop=True)
            # Decode token IDs so a special closing marker omitted by text detokenization is retained.
            summaries = re.findall(r"<summary>\s*(.*?)\s*</summary>", "<summary>\n" + event["text"], re.S)
            if not summaries or not summaries[-1].strip():
                record["status"] = "invalid_forced_summary"
            else:
                summary = summaries[-1].strip()
                event["summary"] = summary
                new_prompt = candidate["base_prompt"] + "<history>" + summary + "</history><think>\n"
                event["reset_prompt"] = new_prompt
                self.reasoning(record, candidate, self.tok.encode(new_prompt, add_special_tokens=False),
                               self.args.round_tokens, 1)
        elif branch == "C_answer":
            suffix = "\n</think>\nFinal answer: \\boxed{"
            suffix_ids = self.tok.encode(suffix, add_special_tokens=False)
            record["inserted_control_tokens"] = len(suffix_ids)
            event = self.call(record, prefix_ids + suffix_ids, self.args.answer_tokens,
                              "short_answer_probe", logprobs=True)
            found = first_boxed("\\boxed{" + event["text"])
            record["final_text"] = "\\boxed{" + event["text"]
            if not found:
                record["status"] = "invalid_short_answer"
            else:
                record["pred_boxed"] = found[0]
                record["status"] = "short_answer_review_required"
                used = next((i for i in range(1, len(event["generated_token_ids"]) + 1)
                             if first_boxed("\\boxed{" + self.tok.decode(event["generated_token_ids"][:i], skip_special_tokens=False))), None)
                record["probe_tokens_through_answer"] = used
                probs = (event["selected_token_probabilities"] or [])[:used]
                if probs and all(p is not None for p in probs):
                    record["probe_confidence"] = sum(probs) / len(probs)
        else:
            raise ValueError(branch)
        record["extra_generated_tokens"] = sum(c["generated_tokens"] for c in record["calls"])
        record["total_generated_tokens_with_shared_prefix"] = candidate["cut"] + record["extra_generated_tokens"]
        record["model_call_seconds"] = sum(c["seconds"] for c in record["calls"])
        record["prefill_tokens_total"] = sum(c["input_tokens"] for c in record["calls"])
        record["record_finished"] = True
        self.save(record)
        print(json.dumps({k: record[k] for k in (
            "case", "branch", "status", "pred_boxed", "extra_generated_tokens", "probe_confidence"
        )}, ensure_ascii=False), flush=True)
        return record


BRANCHES = ("A_continue", "B_summary", "C_answer")


def report(output, candidates):
    records = []
    for candidate in candidates:
        for branch in BRANCHES:
            path = output / "branches" / f"{candidate['case']:03d}_{branch}.json"
            if path.exists():
                record = json.loads(path.read_text())
                if record.get("record_finished"):
                    records.append(record)
    old = {}
    path = output / "review.csv"
    if path.exists():
        with path.open(encoding="utf-8-sig", newline="") as f:
            old = {(r["case"], r["branch"]): r for r in csv.DictReader(f)}
    fields = ["case", "unique_id", "cut", "branch", "status", "pred_boxed", "reference_answer",
              "extra_generated_tokens", "prefill_tokens_total", "model_call_seconds", "probe_confidence",
              "prefix_probe_confidence", "policy_extra_tokens_including_probe", "manual_correct", "notes"]
    with path.open("w", encoding="utf-8-sig", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader()
        for record in records:
            row = {k: record.get(k, "") for k in fields}
            probe = next((r for r in records if r["case"] == record["case"] and r["branch"] == "C_answer"), None)
            if probe:
                row["prefix_probe_confidence"] = probe["probe_confidence"]
                row["policy_extra_tokens_including_probe"] = record["extra_generated_tokens"] + (
                    probe["extra_generated_tokens"] if record["branch"] != "C_answer" else 0
                )
            previous = old.get((str(record["case"]), record["branch"]), {})
            row.update({k: previous.get(k, "") for k in ("manual_correct", "notes")})
            writer.writerow(row)
    summary = {
        "candidate_count": len(candidates), "finished_branch_records": len(records),
        "cases_with_three_finished_branches": sum(all(any(r["case"] == c["case"] and r["branch"] == b for r in records) for b in BRANCHES) for c in candidates),
        "by_branch": {}, "accuracy": None,
        "note": "Manual grading required. Greedy counterfactual continuations differ from sampled native20. Model-call times exclude shared-prefix generation, initialization, and analysis; no online speedup claim.",
        "probe_cost_accounting": "For a policy that probes before acting: A and B pay their extra tokens plus C probe tokens; C pays its probe tokens once. Attention monitoring is not yet implemented or costed.",
    }
    for branch in BRANCHES:
        group = [r for r in records if r["branch"] == branch]
        summary["by_branch"][branch] = {
            "n": len(group), "status_counts": dict(Counter(r["status"] for r in group)),
            "mean_extra_generated_tokens": sum(r["extra_generated_tokens"] for r in group) / len(group) if group else None,
            "model_call_seconds_total": sum(r["model_call_seconds"] for r in group),
        }
    dump(output / "summary.json", summary)
    return summary


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--baseline", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--cut", type=int, default=4096)
    parser.add_argument("--boundary-window", type=int, default=128)
    parser.add_argument("--limit", type=int, default=8)
    parser.add_argument("--round-tokens", type=int, default=8192)
    parser.add_argument("--total-tokens", type=int, default=16384)
    parser.add_argument("--max-segments", type=int, default=3)
    parser.add_argument("--summary-tokens", type=int, default=1024)
    parser.add_argument("--answer-tokens", type=int, default=128)
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--prepare-only", action="store_true")
    args = parser.parse_args()
    assert 0 < args.cut <= args.cut + args.boundary_window < args.round_tokens
    assert args.total_tokens > args.round_tokens and args.max_segments >= 2
    assert min(args.limit, args.summary_tokens, args.answer_tokens) > 0
    baseline = args.baseline.resolve()
    cfg = json.loads((baseline / "run_config.json").read_text())
    assert cfg["model_revision"] == MODEL_SHA
    assert sha(baseline / "reference_runner.py") == cfg["reference_runner_sha256"]
    assert sha(baseline / "native_batch_check.py") == cfg["script_sha256"]
    cases = [json.loads(p.read_text()) for p in sorted((baseline / "cases").glob("*.json"))]
    assert len(cases) == 20 and all(r["completed"] for r in cases), "Expected completed native20 diagnostics"
    assert [r["case"] for r in cases] == list(range(1, 21))
    from transformers import AutoTokenizer
    tok = AutoTokenizer.from_pretrained(cfg["model"], local_files_only=True)
    candidates, skipped = choose_candidates(cases, tok, args.cut, args.boundary_window)
    selected = candidates[:args.limit]
    assert selected, "No eligible reasoning prefixes"
    print("CANDIDATES", [(c["case"], c["cut"]) for c in candidates], flush=True)
    out = args.output.resolve()
    config = {
        "model": cfg["model"], "model_revision": MODEL_SHA,
        "baseline_config_sha256": sha(baseline / "run_config.json"),
        "baseline_cases_sha256": hashlib.sha256("".join(sha(p) for p in sorted((baseline / "cases").glob("*.json"))).encode()).hexdigest(),
        "script_sha256": sha(Path(__file__)), "cut_target": args.cut,
        "boundary_window": args.boundary_window, "temperature": 0.0, "top_p": 1.0,
        "round_tokens": args.round_tokens, "total_tokens_including_cached_prefix": args.total_tokens,
        "max_segments_including_forced_summary": args.max_segments,
        "summary_tokens": args.summary_tokens, "answer_tokens": args.answer_tokens,
        "dtype": "bfloat16", "prefix_caching": False,
        "probe_confidence_definition": "Mean selected-token probability through the first closed answer box, including its closing delimiter; not semantic correctness probability.",
        "attention_entropy_collected": False,
    }
    if out.exists() and any(out.iterdir()):
        assert args.resume, "Output exists; use --resume"
        assert json.loads((out / "run_config.json").read_text()) == config, "Resume configuration mismatch"
    out.mkdir(parents=True, exist_ok=True)
    (out / "branches").mkdir(exist_ok=True)
    dump(out / "run_config.json", config)
    dump(out / "candidates.json", {"selected": selected, "all_eligible": [{"case": c["case"], "cut": c["cut"]} for c in candidates], "skipped": skipped})
    shutil.copyfile(Path(__file__), out / "branch_pilot.py")
    shutil.copyfile(baseline / "reference_runner.py", out / "reference_runner.py")
    review = Path(__file__).with_name("baseline20_review.json")
    if review.exists():
        shutil.copyfile(review, out / "baseline20_review.json")
    if args.prepare_only:
        print("PREFLIGHT_OK; no model loaded. Candidates selected without correctness labels.", flush=True)
        return
    pending = []
    for candidate in selected:
        for branch in BRANCHES:
            path = out / "branches" / f"{candidate['case']:03d}_{branch}.json"
            if args.resume and path.exists() and json.loads(path.read_text()).get("record_finished"):
                print(f"REUSE case {candidate['case']} {branch}", flush=True)
            else:
                pending.append((candidate, branch))
    if not pending:
        print(json.dumps(report(out, selected), ensure_ascii=False, indent=2))
        return
    import torch
    import vllm
    assert torch.cuda.is_available() and torch.cuda.is_bf16_supported()
    assert vllm.__version__ == "0.8.5", vllm.__version__
    dump(out / "environment.json", {
        "python": sys.executable, "gpu": torch.cuda.get_device_name(0),
        "torch": torch.__version__, "cuda": torch.version.cuda,
        "transformers": importlib.metadata.version("transformers"), "vllm": vllm.__version__,
    })
    native = runpy.run_path(str(baseline / "reference_runner.py"))["inf_thought_process_prompts"]
    print("PREFLIGHT_OK; loading the model once.", flush=True)
    model = vllm.LLM(cfg["model"], tensor_parallel_size=1, dtype="bfloat16", seed=2026, enable_prefix_caching=False)
    pilot = Pilot(model, tok, vllm.SamplingParams, native, args, out)
    try:
        for candidate, branch in pending:
            pilot.run(candidate, branch)
    finally:
        print(json.dumps(report(out, selected), ensure_ascii=False, indent=2), flush=True)


if __name__ == "__main__":
    main()
