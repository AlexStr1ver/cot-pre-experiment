# 可移交的原始参考链接

## 当前主线

- InftyThink（2025 初版，ICLR 2026）：https://arxiv.org/abs/2503.06692
- 官方代码：https://github.com/ZJU-REAL/InftyThink
- 此前固定的源码：https://github.com/ZJU-REAL/InftyThink/blob/780035a0dc4999c2210d7c7396a39bc71651e9cc/inference/infer_single.py
- InftyThink+（2026，ICML 2026）：https://arxiv.org/abs/2602.06960
- 官方代码：https://github.com/ZJU-REAL/InftyThink-Plus
- 当前实验模型：https://huggingface.co/yanyc/InftyThink-1.5B
- 固定模型 revision：https://huggingface.co/yanyc/InftyThink-1.5B/tree/2ffdd84494667fbba35525550f9396492b264e23
- 固定 revision README 原文：https://huggingface.co/yanyc/InftyThink-1.5B/raw/2ffdd84494667fbba35525550f9396492b264e23/README.md
- ASAG（2026）：https://arxiv.org/abs/2606.15070
- ASAG HTML：https://arxiv.org/html/2606.15070v1
- MATH-500 数据：https://huggingface.co/datasets/HuggingFaceH4/MATH-500/tree/6e4ed1a2a79af7d8630a6b768ec859cb5af4d3be

## 历史启发与相关工作

- Halo / Limited Reasoning Space：https://arxiv.org/abs/2602.19281
- Do Latent-CoT Models Think Step-by-Step?：https://arxiv.org/abs/2602.00449
- latent-cot-thinking：https://github.com/jialiang19/latent-cot-thinking
- When Chain-of-Thought Fails, the Solution Hides in the Hidden States：https://arxiv.org/abs/2604.23351
- 对应代码：https://github.com/hmehrafarin/when-cot-fails
- Dynamics Within Latent Chain-of-Thought：https://arxiv.org/abs/2602.08783
- Reasoning Models Know When They're Right：https://arxiv.org/abs/2504.05419
- Gnosis：https://arxiv.org/abs/2512.20578
- 高效推理论文清单：https://github.com/hemingkx/Awesome-Efficient-Reasoning

这些链接用于核对定义、来源与已有工作，不能代替本项目的实测证据。尚未核实 ASAG 官方实现的具体来源，不在此编造代码仓库。
