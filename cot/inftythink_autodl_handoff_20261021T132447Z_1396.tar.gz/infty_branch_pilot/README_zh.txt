本轮目标

验证同一推理前缀下，提前摘要是否比继续推理有收益，以及是否已经可以直接回答。
这是我们编写的干预诊断脚本，不是未经修改的官方基准复现代码。
原模型、原生20题输出与原脚本均不修改。

已完成的原生20题

最终答案正确16/20；错误题号1、6、11、18。
第16题没有boxed，但最终明确回答2220，应计为正确。
5题生成原生摘要，共6次；6次接续均逐字验证为原题加最新摘要。
答案正确不代表中间推导正确；第4、8、13、19题均有此类需要区分的现象。
baseline20_reviewed.csv及baseline20_review.json保存人工判分与审计结果。

候选位置

只使用已保存的第一轮推理；从第4096个生成token开始，最多再等待128个token，
取首个段落边界。没有边界或推理已结束的题跳过。选择不使用参考答案或正确性标签。
本次选中题号和实际切点：1/4103、6/4203、8/4173、10/4105、11/4100、
12/4148、15/4106、19/4096。第18题在窗口内没有段落边界。

三个动作

A_continue：从保存的原始token IDs接着推理；保持原生摘要和接续机制。
B_summary：插入结束思考和开始摘要的控制标记，让模型生成摘要，
随后用原题和该摘要重启推理。摘要格式失败单独记录，已花费的生成开销仍计入B。
C_answer：插入结束思考和短答案前缀，最多生成128个token，提取首个闭合boxed。

所有新增生成统一使用temperature=0、top_p=1，即贪心生成。
已有native20是temperature=0.7的采样轨迹，两轮的准确率不能直接作为策略增益比较。
应比较本轮同前缀的A、B、C；发现效果后再在原采样设置下复核。
每个A/B动作共享相同的生成上限16384减去已生成前缀长度；最多3个推理片段。
B的摘要也消耗该预算。单次摘要最多1024token。A第一段剩余预算为8192减去切点。

成本与信号

保存新增生成token、各次输入token、所有模型调用耗时和控制标记长度。
若实际策略先探针再选择动作，A/B必须额外支付C探针成本。
review.csv的policy_extra_tokens_including_probe已按此规则计算；C的探针只计一次。
置信度是短答案生成段直到首个闭合boxed的平均token概率，包含关闭括号，
它不是答案正确概率。本轮不采集attention熵，也不设置信度阈值。
所有调用重新提供完整输入，关闭前缀缓存以减小分支执行顺序的计时干扰。
耗时只作诊断，不是在线完整策略的加速比；前缀生成、初始化和熵监测不在该耗时内。

运行

在AutoDL激活既有infty-official环境，将本目录放到/root/autodl-tmp/infty_branch_pilot。
cd /root/autodl-tmp/inftythink_official_check
python -u /root/autodl-tmp/infty_branch_pilot/branch_pilot.py --baseline outputs/native5 --output outputs/branch4096 --limit 8 --resume

环境继续使用torch2.6.0+cu124、transformers4.51.3、vllm0.8.5和BF16。
不重新下载模型。模型只加载一次，前缀直接复用native20保存的token IDs。
可先加--prepare-only进行不加载模型的候选检查；随后使用同一命令去掉该参数运行。
中断后重复同一命令，已完成的分支会跳过。诊断失败也作为已完成记录保留。

检查结果

8个前缀共24个分支。summary.json中finished_branch_records应为24，
cases_with_three_finished_branches应为8。这仅表示诊断记录齐全，不表示全答对。
branches目录保存每次模型调用的输入、输出、token IDs、结束原因和开销。
review.csv等待人工核对最终答案，accuracy保持null。

验证边界

本地已做语法检查、真实tokenizer的8个切点检查、真实原生多轮日志回放、
强制摘要重启的文本检查、嵌套答案框提取、探针置信度和失败成本记录检查。
这里没有运行GPU模型；AutoDL这次实际输出是下一阶段判断依据。
