本轮目的
复核4096 token附近的干预收益是否受贪心解码重复影响。
保持原8题、完全相同的保存前缀、A/B/C动作、单段上限8192、总生成预算16384、最多3段不变。
A继续、B强制摘要及其后续推理：temperature=0.7，top_p=0.95。
C短答案探针：仍然temperature=0，top_p=1，最多实际生成128 token。
每次请求显式seed = 2026 + 1000*case + 当前分支中从0开始的调用序号，便于中断恢复。
这是匹配原生实验的采样参数，并不承诺重现原生实验的同一随机轨迹。
这个脚本是我们的实验包装，不是作者原封不动的论文评测代码。
旧脚本、模型、native5以及branch4096目录均不修改。

上一轮人工核对
A：4/8正确，2/8未完成，平均新增3608.625 token。
B：4/8正确，4/8未完成，平均新增5828.75 token。
C：4/8正确，平均实际新增128 token。
第8题摘要比继续省token，但短答也已经正确。
第12题A重复到单段上限，B与C正确。
第19题A正确，B未完成，C错误。
第11题C错误而平均所选token概率为0.98547；这不是答案正确概率。
只按最终答案判分；第8、19题部分推导有错误，不能据此声称证明过程正确。
详见branch4096_audit.json。旧输出中的manual_correct留空不影响此次独立人工核对。

运行
将infty_sampling_check.zip上传到/root/autodl-tmp。

source /root/autodl-tmp/venvs/infty-official/bin/activate
cd /root/autodl-tmp
python -m zipfile -e infty_sampling_check.zip .
cd /root/autodl-tmp/inftythink_official_check
mkdir -p outputs
export HF_HOME=/root/autodl-tmp/hf-cache
export HF_HUB_OFFLINE=1
export TOKENIZERS_PARALLELISM=false
set -o pipefail

python /root/autodl-tmp/infty_sampling_check/branch_sampling_check.py \
  --baseline outputs/native5 --output outputs/branch4096_sampled \
  --cut 4096 --limit 8 --temperature 0.7 --top-p 0.95 --seed 2026 \
  --resume --prepare-only \
  2>&1 | tee outputs/branch4096_sampled_preflight.log

预检查通过后运行：

python -u /root/autodl-tmp/infty_sampling_check/branch_sampling_check.py \
  --baseline outputs/native5 --output outputs/branch4096_sampled \
  --cut 4096 --limit 8 --temperature 0.7 --top-p 0.95 --seed 2026 \
  --resume \
  2>&1 | tee -a outputs/branch4096_sampled_console.log

python -m zipfile -c outputs/branch4096_sampled_results.zip \
  outputs/branch4096_sampled \
  outputs/branch4096_sampled_preflight.log \
  outputs/branch4096_sampled_console.log

预检查应该打印以下8组(case,cut)：
[(1,4103),(6,4203),(8,4173),(10,4105),(11,4100),(12,4148),(15,4106),(19,4096)]
随后显示PREFLIGHT_OK；预检查不会加载模型。
本轮输出24份完成的诊断记录。“record_finished”表示记录写完，并不保证推理正常结束或答案正确。
如中断，使用相同运行指令和--resume；不要更改已有输出目录对应的脚本或参数。

需要返回
只上传outputs/branch4096_sampled_results.zip；无需上传模型或重跑native20。
保留所有答错、无答案和截断记录，不按正确率筛选文件。

下一轮的判据
1. 在相同预算下逐题比较A/B/C最终答案与未完成次数。
2. 检查B是否存在C尚不能正确回答、而B能正确且有实际收益的位置。
3. 若B仍无相对C的独立收益，暂停摘要触发器的阈值工作；重新评估早停方向。
4. 若B有独立收益，再固定小规模位置对照，之后验证内部信号在长度以外的预测价值。
5. 单个采样种子只用于排查解码敏感性；不能据此宣称稳定的准确率增益。

成本口径
表中的extra_generated_tokens是截断后新生成的全部token；B包含摘要与重置后的生成。
C实际通常生成128 token，不能只计算最初闭合答案所需的2到8 token。
若线上策略先探针再选A/B，应额外计入C的全部生成与重新预填充成本；review.csv已给出探针生成token的合计口径。
尚未采集attention熵，也尚未计入其监控开销。
模型调用计时不包含共同前缀生成与初始化，不是端到端加速评测。
本地完成真实tokenizer、24个分支/38次调用回放、参数与seed、重置、预检查与恢复保护检查。
本地没有运行GPU模型；真正的采样行为需要在你的4090上验证。
