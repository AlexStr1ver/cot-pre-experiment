#!/usr/bin/env python3
"""Replay the author's summary parser against one existing case; CPU/stdlib only."""
import argparse
import json
import runpy
from pathlib import Path


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--case', required=True)
    args = parser.parse_args()
    root = Path(__file__).resolve().parent
    original = runpy.run_path(str(root / 'upstream/infer_single.py'),
                             run_name='_upstream_parser_audit')
    compatible = runpy.run_path(str(root / 'infer_single_compat.py'),
                               run_name='_compatible_parser_audit')
    record = json.loads(Path(args.case).read_text(encoding='utf-8'))
    native = [t for t in record['turns'] if t['kind'] == 'native_summary']
    if not native:
        raise SystemExit('Choose an existing case that contains a native_summary turn.')
    results = []
    for turn in native:
        full = turn['prompt'] + turn['text']
        expected_history = '<history>' + turn['summary'] + '</history>'
        old = original['inf_thought_process_prompts'](full)
        new = compatible['inf_thought_process_prompts'](full)
        legacy = full.replace('</think><summary>', '</think>\n<summary>')
        old_legacy = original['inf_thought_process_prompts'](legacy)
        new_legacy = compatible['inf_thought_process_prompts'](legacy)
        expected = turn['prompt'].split('<think>', 1)[0] + expected_history
        result = {
            'round': turn['round'],
            'adjacent_think_summary_markers': '</think><summary>' in full,
            'original_keeps_summary': expected_history in old,
            'compatible_keeps_summary': expected_history in new,
            'compatible_output_equals_question_plus_summary': new == expected,
            'legacy_newline_format_produces_identical_outputs': old_legacy == new_legacy,
        }
        results.append(result)
        assert result['compatible_keeps_summary'], result
        assert result['compatible_output_equals_question_plus_summary'], result
        assert result['legacy_newline_format_produces_identical_outputs'], result
    print(json.dumps({'unique_id': record['unique_id'], 'checks': results},
                     ensure_ascii=False, indent=2))
    print('PARSER_COMPATIBILITY_OK')


if __name__ == '__main__':
    main()
