# InftyThink 官方示例：单题兼容性检查

目标：使用作者的原始 vLLM 推理逻辑，检查当前公开权重是否能完成自主推理、摘要和接续。先跑一题，再决定后续小样本基线。

这不是完整的论文指标复现。官方仓库没有为该示例锁定依赖；本包的依赖版本是为现有 Python 3.10、驱动 550.120、CUDA 12.4 环境选择的兼容组合。GPU 运行需要在你的 AutoDL 上验证。

## 代码来源与改动

- 官方仓库：https://github.com/ZJU-REAL/InftyThink
- 固定 commit：780035a0dc4999c2210d7c7396a39bc71651e9cc
- upstream/infer_single.py：未改动的官方源码。
- infer_single_local.py：仅替换 model_path 和 question 两行的官方副本，用于对照。
- infer_single_compat.py：在上述两行配置以外，只将摘要正则中两个标记间的换行要求改为允许空白。模型指向已下载的 InftyThink-1.5B；题目使用之前那道二次方程开发题，参考答案为 6。
- CHANGES.diff：官方原文到兼容副本的完整差异，只有三行。没有加入 force_once、没有改写摘要内容、没有替换作者的迭代循环。
- upstream/LICENSE：保留作者的 MIT 许可证。
- source.json、VALIDATION.json：源码校验和、改动及验证范围。

官方示例使用原始 User:/Assistant: 前缀，每轮最多生成 8192 token，最多 50 轮。它与先前 day1.py 的模板、预算和引擎不同，本次只检查兼容性和实际输出，不能把运行耗时直接用来宣称两种方法的加速比。

已用先前 normal_1 的真实日志复现一个格式差异：当前权重输出相邻的 `</think><summary>`，而官方正则要求两者之间存在换行。原函数会进入异常回退分支，返回不含摘要的题目输入。兼容副本只把此处的 `\n` 改为 `\s*`，以同时接受相邻标记与原先的换行格式。这个修复只影响摘要识别，不决定何时生成摘要。

## 1. 解压

将 inftythink_official_check.zip 上传到 /root/autodl-tmp，然后执行：

```bash
cd /root/autodl-tmp
python -m zipfile -e inftythink_official_check.zip .
cd inftythink_official_check
```

## 2. 先用已有日志做 CPU 格式检查

这一步不安装 vLLM、不加载模型、不调用 GPU：

```bash
python check_summary_format.py \
  --case /root/autodl-tmp/inftythink_day1/outputs/normal_1/cases/001.txt
```

预期 original_keeps_summary 为 false，compatible_keeps_summary 为 true，最后显示 PARSER_COMPATIBILITY_OK。此时只证明解析兼容修复通过；还没有验证 GPU 推理、原始提示格式与权重的匹配，以及数学正确率。

## 3. 创建独立环境并安装

```bash
python -m venv /root/autodl-tmp/venvs/infty-official
source /root/autodl-tmp/venvs/infty-official/bin/activate
python -m pip install --upgrade pip -i https://pypi.tuna.tsinghua.edu.cn/simple
python -m pip install -r requirements.txt \
  --index-url https://pypi.tuna.tsinghua.edu.cn/simple \
  --extra-index-url https://download.pytorch.org/whl/cu124 \
  --prefer-binary
```

模型权重和数据继续使用原目录，不再下载。独立环境会安装自己的 Python 依赖，pip 会尽可能复用已有下载缓存。安装需额外磁盘空间；先前环境保持原样。

## 4. 检查环境和本地文件

只在安装命令成功后执行：

```bash
mkdir -p outputs
set -o pipefail
python - <<'PY' 2>&1 | tee outputs/environment_check.txt
import sys, json
from pathlib import Path
import torch, transformers, vllm
print('Python:', sys.executable)
print('torch:', torch.__version__)
print('torch CUDA:', torch.version.cuda)
print('transformers:', transformers.__version__)
print('vllm:', vllm.__version__)
print('CUDA available:', torch.cuda.is_available())
assert torch.__version__.split('+')[0] == '2.6.0'
assert torch.version.cuda == '12.4'
assert transformers.__version__ == '4.51.3'
assert vllm.__version__ == '0.8.5'
assert torch.cuda.is_available()
model = Path('/root/autodl-tmp/inftythink_day1/models/InftyThink-1.5B')
assert (model / 'config.json').is_file(), model
assert list(model.glob('*.safetensors')), 'Missing model weights'
manifest = json.loads(Path('/root/autodl-tmp/inftythink_day1/manifest.json').read_text())
print('model revision:', manifest['model_revision'])
assert manifest['model_revision'] == '2ffdd84494667fbba35525550f9396492b264e23'
x = torch.ones((16, 16), device='cuda')
assert (x @ x)[0, 0].item() == 16
print('ENVIRONMENT_OK')
PY
```

import 和矩阵计算通过，不代表 vLLM 模型引擎已经通过验证；下一步才会实际加载权重。

## 5. 执行官方逻辑及一行格式兼容修复

```bash
export HF_HOME=/root/autodl-tmp/hf-cache
export HF_HUB_OFFLINE=1
export TOKENIZERS_PARALLELISM=false
set -o pipefail
python -u infer_single_compat.py 2>&1 | tee outputs/official_case1.log
```

这条命令运行作者的推理循环及上面明确记录的一行格式兼容修复，不调用 day1.py。模型自主决定何时生成摘要。请勿将其描述成完全未改动的官方代码。

官方代码对“完成”的判断只检查输出是否包含 summary 标记，因此脚本退出不能单独证明答案完整。需要看原始日志是否产生了最终答案、摘要是否闭合，以及下一轮输入是否确实保留原题和摘要、移除了旧推理。没有出现摘要也可能是题目在一轮内结束，需要结合内容判断。

若长时间只重复相同内容，可按 Ctrl+C 结束并保留日志。不要在未检查日志前启动 20 题或增加预算。

## 6. 带回结果

上传 outputs/environment_check.txt 和 outputs/official_case1.log。根据日志区分：

1. 环境或模型加载失败；
2. 官方提示格式与当前权重不匹配；
3. 自主摘要、接续成功但答案错误；
4. 正常生成完整答案；
5. 单轮达到长度上限或循环重复，尚未完成。

先确认官方示例与当前公开权重的兼容性。随后再固定提示格式、预算和采样设置，建立小样本原生基线；在相同执行器内加入干预后才能比较策略效果。
