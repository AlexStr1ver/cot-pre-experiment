# InftyThink 第1天：最小推理、摘要与接续检查

目标：在 AutoDL 单卡上加载现成 InftyThink-1.5B，检查正常推理、摘要格式、清除旧推理后从摘要接续的接口，并记录耗时、显存和未完成原因。

本包没有训练，也没有熵或置信度控制器。正常模式采用模型原生摘要；force_once 模式仅尝试在第一轮的指定 token 位置增加一次摘要，用于接口检查，不作为摘要时机优劣的结论。

## 1. 实例和目录

建议 1 张 RTX 4090 24GB，Python 3.10–3.12，带可用 CUDA PyTorch 的镜像（优先 PyTorch 2.6 或更新版本），数据盘留出至少 20GB。PyTorch 使用镜像已有的 CUDA 版本，本包不安装或替换 PyTorch。

将 inftythink_day1.zip 上传到 /root/autodl-tmp。在终端执行：

~~~bash
cd /root/autodl-tmp
unzip inftythink_day1.zip
cd inftythink_day1
nvidia-smi
python -c "import sys, torch; print(sys.executable); print(torch.__version__); print(torch.version.cuda); print(torch.cuda.is_available()); print(torch.cuda.get_device_name(0) if torch.cuda.is_available() else 'NO_CUDA')"
~~~

期望：GPU 能识别，cuda.is_available() 为 True。若不能 import torch、没有 CUDA 或 GPU 名称不符，先解决环境问题，不继续下载和批量运行。

## 2. 安装本包依赖

推荐在新开的实验容器中执行；已有项目环境中请先独立创建环境并安装匹配驱动的 CUDA PyTorch。

~~~bash
python -m pip install -r requirements.txt
python day1.py check
python day1.py selftest
~~~

check 会将 Python、PyTorch、CUDA、GPU、软件包版本写入 outputs/environment.json。selftest 使用模拟引擎检查解析、重启、回退和答案泄漏等控制逻辑；不是 GPU 推理测试。

若安装或 import 报错，保留完整报错。不要先大规模升级 CUDA、重新安装所有依赖或改动其他项目。

## 3. 下载权重，固定数据划分

~~~bash
export HF_HOME=/root/autodl-tmp/hf-cache
python day1.py prepare
~~~

首次需联网下载约 3.55GB 权重及分词器。默认来源：

- 模型：https://huggingface.co/yanyc/InftyThink-1.5B
- 数据：https://huggingface.co/datasets/HuggingFaceH4/MATH-500

脚本记录模型和数据的真实 commit SHA，随后按 SHA 下载，生成 manifest.json。数据按 seed=2026 固定打乱并划分为 dev80/test120/reserve300。

第1天只读取 data/day1_20.jsonl，即开发集的前20题。正确答案只写入结果供人工检查，不进入模型的推理输入。测试集和保留集留待后续使用。

如果网络不可达，停止在下载步骤，保留报错，再决定使用平台网络功能或本地下载上传。不要反复重启推理来解决下载问题。默认不需要 Hugging Face 登录。

如果在已有目录中切换模型或源数据 revision，脚本会要求另建项目目录，避免混合不同实验。

## 4. 检查当前权重的输入格式

~~~bash
python day1.py inspect
~~~

看到 TOKENIZER_AND_TEMPLATE_OK 后，检查 outputs/model_audit.json：

- 架构和层数信息；
- 六个 think/summary/history 标记都能识别为单个 token；
- first_prompt_example 为原题加 assistant 推理前缀；
- restart_prompt_example 包含原题、history 摘要和新的 think 前缀。

当前 checkpoint 的通用 chat_template 会处理已有 assistant 文本中的 </think>。本包只对 user 消息调用模板，然后直接拼接 history 和 think，不把完整推理前缀重新交给聊天模板。

本包依据当前权重的模板和作者公开的冷启动数据格式构造输入。旧版官方 inference 示例使用简化的 User:/Assistant:，不是当前权重的专用模板。仍需通过下一步真实输出确认格式兼容性。

## 5. 先跑1题正常模式

~~~bash
python day1.py run --mode normal --limit 1 --output outputs/normal_1
~~~

加载模型并预热后才开始计时。运行期间会打印轮次。检查：

- outputs/normal_1/cases/001.txt：完整输入和每轮输出；
- outputs/normal_1/summary.json：耗时、显存、状态；
- outputs/normal_1/review.csv：提取答案和标准答案。

eos_without_summary 表示该轮生成 EOS 且没有待接续摘要，仅表示正常终止候选；不代表答案正确。查看最终文本确认是否完整。

若题目简单，没有自然摘要是正常现象。不要为了出现摘要而强迫所有正常题多轮推理。

## 6. 检查一次提前摘要接口

~~~bash
python day1.py run --mode force_once --force-at 1024 --limit 1 --output outputs/force_1
~~~

首轮生成到1024个新 token 时，如果仍在思考且尚未自然进入摘要，就插入 think 结束和 summary 开始标记，最多生成1024个摘要 token。只有取得闭合、非空摘要后，才构造新输入：

~~~text
原题 + <history>摘要</history> + <think>
~~~

旧推理不再放入新输入。若摘要无效，则回到原推理前缀继续，失败尝试的 token 和时间仍计入开销。

forced_status：

- success：生成了有效摘要并已从新上下文继续；
- skipped_ended_before_cut：1024 token前已经结束，无需干预；
- skipped_boundary_or_budget：已到自然摘要/答案边界，或预算不允许；
- invalid_summary_fallback：摘要格式失败，已保留旧历史回退。

如果第一题很快结束，可以运行下面20题，查看是否有实际 forced success；不要将 skipped 计作干预失败。

## 7. 在同一批20题上跑通两种模式

先检查单题完整输出，确认没有明显模板错误，再执行：

~~~bash
python day1.py run --mode normal --limit 20 --output outputs/normal_20
python day1.py run --mode force_once --force-at 1024 --limit 20 --output outputs/force_20
~~~

默认温度0.7、top-p 0.95，每题总生成上限16384 token，单轮生成上限8192 token，最多5轮。首日单轮上限为推理及其后生成的摘要一起留出空间；上限只用于第1天调试，正式测试前再统一锁定配置。两模式采用相同题目和每题随机种子。

每题生成完成即保存。如果运行中断，在同一条命令末尾加 --resume；配置必须与原运行相同。若要改参数，改用新的 --output 目录。

有 CUDA OOM 或导入错误时，保存 outputs/对应目录/last_error.json 及终端 traceback，先排查。不要悄悄降低某一组预算后继续做性能比较。

正常模式的原生摘要长度由模型决定，单轮整体受8192 token约束；1024 token上限仅作用于本包额外请求的强制摘要。第1天不据此比较不同模式的算法效果。

## 8. 人工验收与带回的结果

review.csv 的 manual_correct 列先留空。人工核对最终答案和标准答案后填写 1（正确）或 0（错误），避免把等价数学表达误判。预算用完、无完整答案等状态必须单独记录；只有在统一评价协议下才汇总为准确率。

填完可以重新生成统计：

~~~bash
python day1.py report --output outputs/normal_20
python day1.py report --output outputs/force_20
~~~

重新 report 会保留已经填写的人工标签。初次报告的 accuracy 为 null，这是有意的：本包没有自动数学判等器。

第1天建议带回：

1. outputs/environment.json、outputs/model_audit.json；
2. 两个20题目录里的 summary.json 和 review.csv；
3. 1个正常结束的案例、1个实际成功摘要并接续的案例；
4. 任意报错的 traceback 和 last_error.json。

验收侧重：输入格式正常、可以实际摘要和接续、失败有明确记录、预算及耗时可追踪。20题准确率只用于排错，不能据此宣布方法有效或无效。

## 时延与验证范围

此包是 Transformers + SDPA 的小样本调试实现，不是论文的优化推理引擎。一次 generate 内部使用 KV cache，不同 generate 调用会重新预填充；强制摘要调用也有额外预填充。计时包含这些实际成本，不能把这里的时延当作论文速度复现，也不能据此宣称未来熵策略的加速效果。

已完成6项CPU控制逻辑自测、语法/CLI检查，以及当前实际分词器和输入模板检查。当前环境没有CUDA GPU，未实际加载3.55GB权重运行；真实生成兼容性、GPU显存与耗时需要在你的实例上验收。

## 参考来源

- 官方原版仓库：https://github.com/ZJU-REAL/InftyThink
- 官方原版简化示例：https://github.com/ZJU-REAL/InftyThink/blob/main/inference/infer_single.py
- 官方冷启动数据格式：https://github.com/ZJU-REAL/InftyThink-Plus/blob/main/cold-start/format_inftythink.py
- 模型和数据入口见第3步。
