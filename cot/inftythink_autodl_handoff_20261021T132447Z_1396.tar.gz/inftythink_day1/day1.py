#!/usr/bin/env python3
"""Day-1 interface checks. No training, entropy policy, or automatic math grading."""
from __future__ import annotations

import argparse
import csv
import importlib.metadata
import json
import platform
import random
import re
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent
DEFAULT_MODEL = "yanyc/InftyThink-1.5B"
DATASET = "HuggingFaceH4/MATH-500"
MARKERS = ["<think>", "</think>", "<summary>", "</summary>",
           "<history>", "</history>"]


def dump(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n",
                    encoding="utf-8")


def rows(path):
    return [json.loads(line) for line in Path(path).read_text(
        encoding="utf-8").splitlines() if line.strip()]


def write_rows(path, values):
    Path(path).write_text("".join(json.dumps(v, ensure_ascii=False) + "\n"
                                 for v in values), encoding="utf-8")


def check():
    info = {"python": sys.version, "platform": platform.platform()}
    for name in ["torch", "transformers", "huggingface_hub", "accelerate"]:
        try:
            info[name] = importlib.metadata.version(name)
        except importlib.metadata.PackageNotFoundError:
            info[name] = "NOT_INSTALLED"
    try:
        import torch
        info["cuda_available"] = torch.cuda.is_available()
        info["torch_cuda_build"] = torch.version.cuda
        if torch.cuda.is_available():
            info["gpu"] = torch.cuda.get_device_name(0)
            info["gpu_total_gib"] = round(
                torch.cuda.get_device_properties(0).total_memory / 2**30, 2)
            info["bf16_supported"] = torch.cuda.is_bf16_supported()
    except Exception as exc:
        info["torch_error"] = repr(exc)
    dump(ROOT / "outputs/environment.json", info)
    print(json.dumps(info, ensure_ascii=False, indent=2))
    if not info.get("cuda_available"):
        raise SystemExit("CUDA is unavailable. Resolve the GPU/PyTorch environment first.")


def prepare(args):
    from huggingface_hub import HfApi, hf_hub_download, snapshot_download
    api = HfApi()
    model_sha = api.model_info(args.repo, revision=args.revision).sha
    data_sha = api.dataset_info(DATASET).sha
    previous = ROOT / "manifest.json"
    if previous.exists():
        old = json.loads(previous.read_text())
        if (old["model_repo"] != args.repo or old["model_revision"] != model_sha
                or old["dataset_revision"] != data_sha):
            raise RuntimeError("Different source revisions already exist. Use a new project directory.")
    target = ROOT / "models/InftyThink-1.5B"
    snapshot_download(args.repo, revision=model_sha, local_dir=str(target),
                      allow_patterns=["*.json", "*.jinja", "*.safetensors", "*.md"])
    source = hf_hub_download(DATASET, "test.jsonl", repo_type="dataset",
                             revision=data_sha)
    dataset = rows(source)
    assert len(dataset) == 500, f"Unexpected dataset size: {len(dataset)}"
    assert len({r["unique_id"] for r in dataset}) == 500
    order = list(range(len(dataset)))
    random.Random(2026).shuffle(order)
    shuffled = [dataset[i] for i in order]
    out = ROOT / "data"
    out.mkdir(exist_ok=True)
    splits = {"dev80": shuffled[:80], "test120": shuffled[80:200],
              "reserve300": shuffled[200:]}
    for name, values in splits.items():
        write_rows(out / (name + ".jsonl"), values)
    write_rows(out / "day1_20.jsonl", splits["dev80"][:20])
    manifest = {
        "model_repo": args.repo, "model_revision": model_sha,
        "model_local": "models/InftyThink-1.5B",
        "dataset": DATASET, "dataset_revision": data_sha, "split_seed": 2026,
        "split_ids": {name: [r["unique_id"] for r in values]
                      for name, values in splits.items()},
        "day1_ids": [r["unique_id"] for r in splits["dev80"][:20]],
    }
    dump(previous, manifest)
    print("PREPARE_OK")
    print("Day 1 uses the first 20 development examples only.")
    print("Model revision:", model_sha)
    print("Dataset revision:", data_sha)


def load_tokenizer(model_path):
    from transformers import AutoTokenizer
    tok = AutoTokenizer.from_pretrained(model_path, local_files_only=True)
    for tag in MARKERS:
        encoded = tok.encode(tag, add_special_tokens=False)
        if len(encoded) != 1:
            raise RuntimeError(f"Expected a single token for {tag}, got {encoded}")
    if tok.pad_token_id is None:
        tok.pad_token = tok.eos_token
    return tok


def prompt_for(tok, question, summary=None):
    # Apply the supplied template only to the user message.
    # Do not re-template an assistant reasoning prefix: this checkpoint's
    # generic chat template removes text before </think>.
    base = tok.apply_chat_template(
        [{"role": "user", "content": question}],
        tokenize=False, add_generation_prompt=True)
    if summary is not None:
        base += "<history>\n" + summary + "\n</history>"
    return base + "<think>\n"


def inspect(args):
    tok = load_tokenizer(args.model)
    config = json.loads((Path(args.model) / "config.json").read_text())
    info = {
        "architecture": config.get("architectures"),
        "layers": config.get("num_hidden_layers"),
        "heads": config.get("num_attention_heads"),
        "bos_token": tok.bos_token, "bos_token_id": tok.bos_token_id,
        "eos_token": tok.eos_token, "eos_token_id": tok.eos_token_id,
        "markers": {m: tok.encode(m, add_special_tokens=False)[0] for m in MARKERS},
        "first_prompt_example": prompt_for(tok, "What is 1 + 1?"),
        "restart_prompt_example": prompt_for(
            tok, "What is 1 + 1?", "Two units have been identified."),
    }
    dump(ROOT / "outputs/model_audit.json", info)
    print(json.dumps(info, ensure_ascii=False, indent=2))
    print("TOKENIZER_AND_TEMPLATE_OK")


def extract_summary(text):
    matches = re.findall(r"<summary>\s*(.*?)\s*</summary>", text, re.S)
    return matches[-1].strip() if matches and matches[-1].strip() else None


def last_boxed(text):
    starts = list(re.finditer(r"\\boxed\s*\{", text))
    for match in reversed(starts):
        begin = match.end()
        depth = 1
        for index in range(begin, len(text)):
            if text[index] == "{":
                depth += 1
            elif text[index] == "}":
                depth -= 1
                if depth == 0:
                    return text[begin:index].strip()
    return None


class Engine:
    def __init__(self, args, tok):
        import torch
        from transformers import AutoModelForCausalLM
        if not torch.cuda.is_available():
            raise RuntimeError("Run on a CUDA GPU.")
        self.torch, self.args, self.tok = torch, args, tok
        dtype = torch.bfloat16 if torch.cuda.is_bf16_supported() else torch.float16
        self.model = AutoModelForCausalLM.from_pretrained(
            args.model, local_files_only=True, dtype=dtype,
            attn_implementation="sdpa", low_cpu_mem_usage=True).to("cuda:0").eval()
        self.model.requires_grad_(False)
        self.calls = []
        print("MODEL_LOADED; warm-up starts.")
        self.generate(prompt_for(tok, "What is 1 + 1?"), 8)
        self.calls.clear()
        print("WARMUP_OK")

    def generate(self, prompt, max_tokens):
        from transformers import StoppingCriteria, StoppingCriteriaList
        torch, tok = self.torch, self.tok
        end_id = tok.encode("</summary>", add_special_tokens=False)[0]

        class EndSummary(StoppingCriteria):
            def __call__(self, input_ids, scores, **kwargs):
                return input_ids[0, -1].item() == end_id

        encoded = tok(prompt, return_tensors="pt", add_special_tokens=False).to("cuda:0")
        n_input = encoded["input_ids"].shape[1]
        torch.cuda.synchronize()
        start = time.perf_counter()
        with torch.inference_mode():
            result = self.model.generate(
                **encoded, max_new_tokens=max_tokens, do_sample=True,
                temperature=self.args.temperature, top_p=self.args.top_p,
                use_cache=True, output_attentions=False,
                eos_token_id=tok.eos_token_id, pad_token_id=tok.pad_token_id,
                stopping_criteria=StoppingCriteriaList([EndSummary()]))
        torch.cuda.synchronize()
        elapsed = time.perf_counter() - start
        new_ids = result[0, n_input:].tolist()
        text = tok.decode(new_ids, skip_special_tokens=False)
        self.calls.append({"input_tokens": n_input, "generated_tokens": len(new_ids),
                           "seconds": elapsed})
        ended = bool(new_ids and new_ids[-1] == tok.eos_token_id)
        return {"text": text, "tokens": len(new_ids), "ended": ended}


def run_case(engine, tok, item, args):
    prefix = prompt_for(tok, item["problem"])
    turns, consumed, native, forced = [], 0, 0, "not_requested"
    final_text, status = "", "iteration_limit"
    attempted = False
    if args.mode == "force_once":
        forced = "not_reached"
    engine.calls.clear()
    for round_id in range(args.max_rounds):
        remaining = args.total_tokens - consumed
        if remaining <= 0:
            status = "total_token_limit"
            break
        cap = min(args.round_tokens, remaining)
        print(f"  round={round_id + 1}, remaining_tokens={remaining}", flush=True)
        force_here = args.mode == "force_once" and not attempted and round_id == 0
        event = {"round": round_id + 1, "prompt": prefix}
        if force_here:
            attempted = True
            piece = engine.generate(prefix, min(args.force_at, cap))
            consumed += piece["tokens"]
            text, ended = piece["text"], piece["ended"]
            safe = (piece["tokens"] >= args.force_at and not ended
                    and "<summary>" not in text and "</think>" not in text)
            if safe and args.total_tokens - consumed > 0:
                summary_prefix = prefix + text + "\n</think><summary>\n"
                compressed = engine.generate(
                    summary_prefix, min(args.summary_tokens, args.total_tokens - consumed))
                consumed += compressed["tokens"]
                summary = extract_summary("<summary>\n" + compressed["text"])
                event["forced_attempt"] = compressed["text"]
                if summary is not None:
                    event.update(kind="forced_summary", text=text, summary=summary)
                    turns.append(event)
                    prefix = prompt_for(tok, item["problem"], summary)
                    forced = "success"
                    continue
                forced = "invalid_summary_fallback"
            elif ended:
                forced = "skipped_ended_before_cut"
            else:
                forced = "skipped_boundary_or_budget"
            # A failed forced summary is never used as history. Its tokens and
            # time remain charged, then continuation resumes the original prefix.
            if (not ended and "</summary>" not in text
                    and consumed < args.total_tokens and piece["tokens"] < cap):
                rest = engine.generate(
                    prefix + text,
                    min(cap - piece["tokens"], args.total_tokens - consumed))
                consumed += rest["tokens"]
                text += rest["text"]
                ended = rest["ended"]
        else:
            piece = engine.generate(prefix, cap)
            consumed += piece["tokens"]
            text, ended = piece["text"], piece["ended"]
        summary = extract_summary(text)
        if summary is not None:
            event.update(kind="native_summary", text=text, summary=summary)
            turns.append(event)
            native += 1
            prefix = prompt_for(tok, item["problem"], summary)
            continue
        if "<summary>" in text or "</summary>" in text:
            status = "invalid_native_summary"
        elif ended:
            status = "eos_without_summary"
        elif consumed >= args.total_tokens:
            status = "total_token_limit"
        else:
            status = "round_token_limit"
        event.update(kind="terminal", text=text)
        turns.append(event)
        final_text = text.rsplit("</think>", 1)[-1].strip()
        break
    return {
        "unique_id": item["unique_id"], "problem": item["problem"],
        "gold_answer": item["answer"], "mode": args.mode, "status": status,
        "forced_status": forced, "native_summaries": native,
        "generated_tokens_total": consumed,
        "prefill_tokens_processed": sum(c["input_tokens"] for c in engine.calls),
        "generation_call_seconds": sum(c["seconds"] for c in engine.calls),
        "pred_boxed": last_boxed(final_text), "final_text": final_text,
        "turns": turns, "calls": engine.calls.copy(),
    }


def run(args):
    import torch
    from transformers import set_seed
    examples = rows(args.data)[:args.limit]
    if not examples:
        raise RuntimeError("No examples selected.")
    out = Path(args.output)
    out.mkdir(parents=True, exist_ok=True)
    config = vars(args).copy()
    config.pop("func", None)
    config.pop("resume", None)
    manifest_file = ROOT / "manifest.json"
    if manifest_file.exists():
        manifest = json.loads(manifest_file.read_text())
        config["source_manifest"] = {
            k: manifest[k] for k in ["model_repo", "model_revision",
                                    "dataset", "dataset_revision", "split_seed"]}
    config_file = out / "run_config.json"
    if config_file.exists() and json.loads(config_file.read_text()) != config:
        raise RuntimeError("Existing output has a different configuration. Use a new --output.")
    dump(config_file, config)
    result_file = out / "results.jsonl"
    done = {r["unique_id"] for r in rows(result_file)} if result_file.exists() else set()
    if done and not args.resume:
        raise RuntimeError("Output exists. Use --resume or a new --output.")
    tok = load_tokenizer(args.model)
    engine = Engine(args, tok)
    for i, item in enumerate(examples):
        if item["unique_id"] in done:
            continue
        set_seed(args.seed + i)
        torch.cuda.reset_peak_memory_stats()
        torch.cuda.synchronize()
        start = time.perf_counter()
        try:
            record = run_case(engine, tok, item, args)
        except Exception as exc:
            dump(out / "last_error.json", {"unique_id": item["unique_id"],
                                          "error": repr(exc), "mode": args.mode})
            raise
        torch.cuda.synchronize()
        record["end_to_end_seconds"] = time.perf_counter() - start
        record["peak_allocated_gib"] = torch.cuda.max_memory_allocated() / 2**30
        record["peak_reserved_gib"] = torch.cuda.max_memory_reserved() / 2**30
        record["seed"] = args.seed + i
        with result_file.open("a", encoding="utf-8") as handle:
            handle.write(json.dumps(record, ensure_ascii=False) + "\n")
        case_dir = out / "cases"
        case_dir.mkdir(exist_ok=True)
        case_path = case_dir / (str(i + 1).zfill(3) + ".txt")
        case_path.write_text(json.dumps(record, ensure_ascii=False, indent=2), encoding="utf-8")
        print(json.dumps({
            "case": i + 1, "id": record["unique_id"], "status": record["status"],
            "forced": record["forced_status"], "boxed": record["pred_boxed"],
            "seconds": round(record["end_to_end_seconds"], 2),
            "tokens": record["generated_tokens_total"],
            "peak_gib": round(record["peak_allocated_gib"], 2)}, ensure_ascii=False), flush=True)
    report(argparse.Namespace(output=args.output))


def report(args):
    out = Path(args.output)
    results = rows(out / "results.jsonl")
    if not results:
        raise RuntimeError("No completed records.")
    fields = ["unique_id", "mode", "status", "forced_status", "pred_boxed",
              "gold_answer", "manual_correct", "end_to_end_seconds",
              "generated_tokens_total", "native_summaries", "peak_allocated_gib"]
    review = out / "review.csv"
    existing = {}
    if review.exists():
        with review.open(encoding="utf-8-sig", newline="") as handle:
            existing = {r["unique_id"]: r.get("manual_correct", "")
                        for r in csv.DictReader(handle)}
    with review.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for record in results:
            values = {k: record.get(k, "") for k in fields}
            values["manual_correct"] = existing.get(record["unique_id"], "")
            writer.writerow(values)
    statuses = {}
    for r in results:
        statuses[r["status"]] = statuses.get(r["status"], 0) + 1
    summary = {
        "n": len(results), "status_counts": statuses,
        "boxed_extraction_rate": sum(r["pred_boxed"] is not None for r in results) / len(results),
        "native_summary_count": sum(r["native_summaries"] for r in results),
        "forced_success_count": sum(r["forced_status"] == "success" for r in results),
        "mean_seconds": sum(r["end_to_end_seconds"] for r in results) / len(results),
        "mean_generated_tokens": sum(r["generated_tokens_total"] for r in results) / len(results),
        "max_peak_allocated_gib": max(r["peak_allocated_gib"] for r in results),
        "accuracy": None,
        "note": "Box extraction and EOS are format checks, not correctness. Fill review.csv manually.",
        "runtime": "Transformers/SDPA debug runner. KV is reused within a generation call only; "
                   "calls re-prefill. Timing is diagnostic, not paper latency reproduction.",
    }
    marked = [v for v in existing.values() if v in {"0", "1"}]
    if marked:
        summary["manual_graded_n"] = len(marked)
        summary["manual_accuracy_on_graded"] = sum(map(int, marked)) / len(marked)
    dump(out / "summary.json", summary)
    print(json.dumps(summary, ensure_ascii=False, indent=2))


def selftest():
    import unittest
    from types import SimpleNamespace

    class FakeTokenizer:
        def apply_chat_template(self, messages, **kwargs):
            return "BOS USER " + messages[0]["content"] + " ASSISTANT "

    class FakeEngine:
        def __init__(self, pieces):
            self.pieces = iter(pieces)
            self.calls = []
            self.prompts = []

        def generate(self, prompt, cap):
            self.prompts.append(prompt)
            piece = next(self.pieces)
            assert piece["tokens"] <= cap
            self.calls.append({"input_tokens": len(prompt), "seconds": 0.01,
                               "generated_tokens": piece["tokens"]})
            return piece

    class Checks(unittest.TestCase):
        def test_nested_box(self):
            self.assertEqual(last_boxed(r"x \boxed{\frac{1}{2}}"), r"\frac{1}{2}")
            self.assertIsNone(last_boxed(r"\boxed{unfinished"))

        def test_only_complete_summary(self):
            self.assertIsNone(extract_summary("<summary>unfinished"))
            self.assertIsNone(extract_summary("<summary> </summary>"))
            self.assertEqual(extract_summary("<summary> progress </summary>"), "progress")

        def test_successful_restart_forgets_old_text(self):
            engine = FakeEngine([
                {"text": "OLD_DETAILED_REASONING", "tokens": 2, "ended": False},
                {"text": "COMPACT_STATE</summary>", "tokens": 2, "ended": False},
                {"text": r"</think>\boxed{7}", "tokens": 2, "ended": True}])
            args = SimpleNamespace(mode="force_once", max_rounds=3,
                                   total_tokens=20, round_tokens=10,
                                   force_at=2, summary_tokens=5)
            item = {"unique_id": "one", "problem": "QUESTION", "answer": "GOLD_SECRET"}
            record = run_case(engine, FakeTokenizer(), item, args)
            self.assertEqual(record["forced_status"], "success")
            self.assertEqual(record["pred_boxed"], "7")
            self.assertEqual(record["generated_tokens_total"], 6)
            self.assertNotIn("OLD_DETAILED_REASONING", engine.prompts[-1])
            self.assertIn("COMPACT_STATE", engine.prompts[-1])
            self.assertTrue(all("GOLD_SECRET" not in p for p in engine.prompts))

        def test_failed_summary_rolls_back_but_cost_is_counted(self):
            engine = FakeEngine([
                {"text": "OLD_TEXT", "tokens": 2, "ended": False},
                {"text": "BAD_UNFINISHED", "tokens": 3, "ended": False},
                {"text": r"</think>\boxed{4}", "tokens": 2, "ended": True}])
            args = SimpleNamespace(mode="force_once", max_rounds=3,
                                   total_tokens=20, round_tokens=10,
                                   force_at=2, summary_tokens=5)
            item = {"unique_id": "two", "problem": "Q", "answer": "GOLD"}
            record = run_case(engine, FakeTokenizer(), item, args)
            self.assertEqual(record["forced_status"], "invalid_summary_fallback")
            self.assertEqual(record["generated_tokens_total"], 7)
            self.assertIn("OLD_TEXT", engine.prompts[-1])
            self.assertNotIn("BAD_UNFINISHED", engine.prompts[-1])

        def test_natural_completion_is_not_forced(self):
            engine = FakeEngine([
                {"text": r"</think>\boxed{2}", "tokens": 1, "ended": True}])
            args = SimpleNamespace(mode="force_once", max_rounds=3,
                                   total_tokens=20, round_tokens=10,
                                   force_at=2, summary_tokens=5)
            item = {"unique_id": "three", "problem": "Q", "answer": "2"}
            record = run_case(engine, FakeTokenizer(), item, args)
            self.assertEqual(record["forced_status"], "skipped_ended_before_cut")
            self.assertEqual(len(engine.calls), 1)

        def test_native_summary_restarts(self):
            engine = FakeEngine([
                {"text": "DETAILS</think><summary>STATE</summary>", "tokens": 3, "ended": False},
                {"text": r"</think>\boxed{5}", "tokens": 2, "ended": True}])
            args = SimpleNamespace(mode="normal", max_rounds=3,
                                   total_tokens=20, round_tokens=10,
                                   force_at=2, summary_tokens=5)
            item = {"unique_id": "four", "problem": "Q", "answer": "5"}
            record = run_case(engine, FakeTokenizer(), item, args)
            self.assertEqual(record["native_summaries"], 1)
            self.assertEqual(record["pred_boxed"], "5")
            self.assertIn("<history>\nSTATE", engine.prompts[-1])
            self.assertNotIn("DETAILS", engine.prompts[-1])

    result = unittest.TextTestRunner(verbosity=2).run(
        unittest.defaultTestLoader.loadTestsFromTestCase(Checks))
    if not result.wasSuccessful():
        raise SystemExit(1)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest="command", required=True)
    commands.add_parser("check")
    p = commands.add_parser("prepare")
    p.add_argument("--repo", default=DEFAULT_MODEL)
    p.add_argument("--revision", default="main")
    p = commands.add_parser("inspect")
    p.add_argument("--model", default=str(ROOT / "models/InftyThink-1.5B"))
    p = commands.add_parser("run")
    p.add_argument("--model", default=str(ROOT / "models/InftyThink-1.5B"))
    p.add_argument("--data", default=str(ROOT / "data/day1_20.jsonl"))
    p.add_argument("--mode", choices=["normal", "force_once"], default="normal")
    p.add_argument("--limit", type=int, default=1)
    p.add_argument("--output", required=True)
    p.add_argument("--seed", type=int, default=2026)
    p.add_argument("--temperature", type=float, default=0.7)
    p.add_argument("--top-p", type=float, default=0.95)
    p.add_argument("--total-tokens", type=int, default=16384)
    p.add_argument("--round-tokens", type=int, default=8192)
    p.add_argument("--max-rounds", type=int, default=5)
    p.add_argument("--force-at", type=int, default=1024)
    p.add_argument("--summary-tokens", type=int, default=1024)
    p.add_argument("--resume", action="store_true")
    p = commands.add_parser("report")
    p.add_argument("--output", required=True)
    commands.add_parser("selftest")
    args = parser.parse_args()
    if args.command == "check":
        check()
    elif args.command == "prepare":
        prepare(args)
    elif args.command == "inspect":
        inspect(args)
    elif args.command == "run":
        if min(args.limit, args.total_tokens, args.round_tokens,
               args.max_rounds, args.force_at, args.summary_tokens) <= 0:
            parser.error("Budgets and limits must be positive.")
        run(args)
    elif args.command == "report":
        report(args)
    else:
        selftest()


if __name__ == "__main__":
    main()
