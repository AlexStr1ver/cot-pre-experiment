#!/usr/bin/env bash
# First-run diagnostics only. Reuses existing AutoDL environment and old files read-only.
set -euo pipefail
ROOT=${1:-/root/autodl-tmp}
PKG=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
PY="$ROOT/venvs/infty-official/bin/python"
MODEL="$ROOT/inftythink_day1/models/InftyThink-1.5B"
NATIVE="$ROOT/inftythink_official_check/outputs/native5"
EXP=$(mktemp -d "$ROOT/infty_signal_first_XXXXXXXX")
printf 'OUTPUT_DIRECTORY=%s\n' "$EXP"

finish() {
    local task_exit=$?
    printf '%s\n' "$task_exit" > "$EXP/exit_status.txt"
    if [ -x "$PY" ]; then
        "$PY" - "$EXP" <<'PY'
import pathlib, sys, zipfile
p = pathlib.Path(sys.argv[1]).resolve()
out = p.parent / (p.name + '_return.zip')
with zipfile.ZipFile(out, 'x', compression=zipfile.ZIP_DEFLATED) as z:
    for f in sorted(p.rglob('*')):
        if f.is_file():
            z.write(f, f.relative_to(p))
print('RETURN_ZIP=' + str(out))
PY
    fi
    return "$task_exit"
}
trap finish EXIT

cd "$PKG"
sha256sum -c checksums.sha256 2>&1 | tee "$EXP/package_checksums.log"
test -x "$PY"
"$PY" preflight.py --root "$ROOT" --output "$EXP/preflight" --require-gpu \
    2>&1 | tee "$EXP/preflight.log"
"$PY" test_signal_smoke.py 2>&1 | tee "$EXP/unit_tests.log"
"$PY" signal_smoke.py --model "$MODEL" --baseline "$NATIVE" \
    --cases 1,6 --cuts 128,256 --query-window 32 --prefill-chunk 128 \
    --probe-tokens 32 --check-short-reference --device cuda \
    --output "$EXP/signals_short" 2>&1 | tee "$EXP/signals_short.log"
