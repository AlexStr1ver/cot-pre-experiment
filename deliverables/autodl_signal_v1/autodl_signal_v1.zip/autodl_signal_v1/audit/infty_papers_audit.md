# InftyThink / InftyThink+ 来源与设置审计（2026-10-22）

## 证据范围

本轮不能读取用户 Windows 的 C:\\Users\\86135\\Desktop\\CoT---2027ACL 路径。云端交接包没有指定的 2503.06692v5.pdf 和 2602.06960v3.pdf。
对 https://arxiv.org/pdf/2503.06692v5 与 https://arxiv.org/pdf/2602.06960v3 的正常 HTTPS 读取均失败，错误为 `Tunnel connection failed: 403 Forbidden`。这是当前出站代理访问限制，没有关闭 TLS 验证或改变网络配置。
因此以下是**官方仓库、官方项目页面源代码和本地 checkpoint 元数据审计**，不声称已经读完用户指定的两版论文。

已通过平台 Git HTTPS 访问下载：
- InftyThink: `https://github.com/ZJU-REAL/InftyThink`，commit `780035a0dc4999c2210d7c7396a39bc71651e9cc`。与交接包记录固定 commit 完全相同。
- InftyThink+: `https://github.com/ZJU-REAL/InftyThink-Plus`，commit `c3ac7ed4365289da1253c7648380223479557278`。
- 两个仓库的 `docs/static/pdfs/sample.pdf` 都是 “A Simple PDF File” 网站模板示例，**不是论文**。
- 本地副本位于本目录的 `upstream-InftyThink` 和 `upstream-InftyThink-Plus`。

## 可核实的对齐信息

| 项目 | 官方来源可核实内容 | 本项目应如何解释 |
|---|---|---|
| 原版机制 | README Overview 和官网方法描述分段推理→自生成摘要→重建上下文，依赖 InftyThink 格式的 SFT | 当前摘要/重置机制在这个技术脉络内 |
| 原版训练来源 | 官网 docs/index.html:235 起：OpenR1-Math；Meta-Llama-3.3-Instruct 生成摘要；README QuickStart 使用 eta=4096 | 这是训练数据构建配置，不能当作推理时每 4096 token 必须外部强制摘要 |
| 原版官方推理例程 | inference/infer_single.py:3–7 使用 User:/Assistant:、MAX_EPOCHS=50；:38 使用 n=1、max_tokens=8192、T=0.7、top_p=0.95、保留特殊 token | native20 的 checkpoint chat template、最多 3 轮是兼容与小规模实验设置；不能称原样复现官方全部协议 |
| 原版主表采样 | docs/index.html:270–272 明确 16 次采样，T=0.7；主表列 Acc、Tok、TPS | native20 的一次请求轨迹/题不是同一统计协议；TPS 也不能直接换成端到端加速比 |
| 原版主表模型 | docs/static/images/main-result.png：Qwen2.5-Math-1.5B、Qwen2.5-Math-7B、Qwen2.5-14B、Qwen2.5-32B、Meta-Llama-3.1-8B | 当前“1.5B”名字不能证明属于其中 Qwen2.5-Math-1.5B 的结果行 |
| Plus 目标 | README:45；docs/index.html:232、247、288 起：SFT 冷启动学格式，轨迹级 RL 学何时摘要、保留什么、如何接续 | “何时摘要”本身已有直接相关工作；新贡献需体现免训练内部信号的增量及动作收益辨识 |
| Plus RL 奖励 | docs/index.html:299–315：正确性奖励乘以效率奖励；效率项为 1-((n_i-1)/phi)^2 | Plus 已优化准确率/迭代数折中，不能仅以“减少摘要轮数”为独有贡献 |
| Plus 主表采样 | docs/index.html:342–344：32 次采样，T=0.7；冷启动-only、task-RL、task+efficiency-RL 三种 InftyThink+ 设置 | 必须识别当前 checkpoint 属于哪一训练阶段，才能选择对应原生 baseline |
| Plus 主表模型 | docs/static/images/main-result.png：DeepSeek-R1-Distill-Qwen-1.5B 和 Qwen3-4B-Base | 与原版主表的 1.5B 基座不同 |
| Plus timing 比较 | docs/index.html:358–379 的注释块题为 Learning When to Compress / Comparison ... summary timing strategies | 提示“比较摘要时机”已是其研究内容；具体方法和数值必须读 v3 论文后再下结论 |
| Plus 代码发布范围 | 顶层 README:49–50 仍写 Codes and documentations are on the way；实际仓库提供 cold-start 目录及 ms-swift 拷贝 | 可审计冷启动格式；不能据此声称拿到了完整 RL 评测实现 |
| Plus 冷启动实现 | cold-start/README.md：OpenThoughts-114k，6k 分段文件，Qwen3-4B-Instruct-2507 摘要、摘要上限 1024；format_inftythink.py:39–56：user question，assistant history + think + summary/conclusion | 与 checkpoint 原题+history+think 的结构一致，但不是权重训练来源的充分证明 |

## checkpoint 映射尚未闭环

本地固定 revision `2ffdd84494667fbba35525550f9396492b264e23` 的模型卡标题为 InftyThink+，并链接 2602.06960；说明项目归属。它没有明示是 cold-start-only、task-RL 还是 task+efficiency-RL 权重，也没有指向主表具体行。

本地 config.json 证实 Qwen2ForCausalLM、28 层、12 query heads、2 KV heads、hidden_size=1536、vocab_size=151936、max_position_embeddings=131072、rope_theta=10000。这些是架构/运行属性，**不能唯一证明基座来源与训练阶段**。config 中 transformers_version=4.57.1 是保存元数据；历史实际执行环境版本为 4.51.3，不应仅凭该字段升级现有环境。

检查过的两份官方顶层 README、Plus 官网源代码、cold-start README 中未找到 `yanyc/InftyThink-1.5B` 或固定 revision 的明确 release mapping。这里的“未找到”仅限这些已检查材料，不证明其他页面或模型仓库历史中不存在证据。

需要补齐的最小证据：
1. 指定 v5、v3 论文全文，确认实验表格、预算、迭代上限、评测数据处理及 timing ablation。
2. 模型发布说明/作者公开记录中，将该固定 revision 映射到基座、SFT 或 RL 阶段、奖励设置、主表行。
3. AutoDL 原机器保留的下载 manifest 可确认实际使用 revision；权重内容缺失时不能在云端再次验证权重哈希。
无需因为当前缺证就更换模型或重训；先将结论限定为该固定 checkpoint 的免训练控制实验。

## 对 idea 与顶会潜力的初判

- 合理性：对一个已会摘要/接续的冻结模型，外部免训练规则可能修正其自然时机，属于可实验检验的假设；旧固定 4k/5k 干预结果无法否定联合信号。
- 新颖性压力：InftyThink+ 已直接优化 when/what/how；ASAG 已使用 attention 状态和置信度做适应性生成。因此“把 ASAG 信号接到摘要动作”本身不足以预判顶会贡献。
- 更强的研究命题是：**在控制长度和阶段后，attention 状态与答案置信度能区分“应结束”与“适合压缩后继续”的不同状态，并预测摘要相对继续的净收益。** 该命题需要配对动作数据和泛化实验。
- 关键风险：信号只反映长度/任务难度；摘要丢失关键状态；高置信错误；采集/探测开销抵消节省；同题多位置/seed 的伪独立样本；预算截断不对称。
- 可发表证据应包括：同 checkpoint 原生摘要、固定/随机时机、长度/阶段规则、单信号和联合信号；若主张通用性，还需至少不同 checkpoint/数据集验证；全部在固定协议下报告准确率-端到端成本曲线、配对不确定性和失败类别。小样本仅用于 go/no-go，不足以确认顶会潜力。
- 不能给接受概率或“已具顶会创新”的结论；当前判断是值得做受控低成本预实验，研究贡献是否成立取决于上述新增证据。

## 可引用的公开定位

- https://github.com/ZJU-REAL/InftyThink/blob/780035a0dc4999c2210d7c7396a39bc71651e9cc/inference/infer_single.py
- https://github.com/ZJU-REAL/InftyThink/blob/780035a0dc4999c2210d7c7396a39bc71651e9cc/docs/index.html
- https://github.com/ZJU-REAL/InftyThink-Plus/blob/c3ac7ed4365289da1253c7648380223479557278/docs/index.html
- https://github.com/ZJU-REAL/InftyThink-Plus/blob/c3ac7ed4365289da1253c7648380223479557278/cold-start/format_inftythink.py
- https://huggingface.co/yanyc/InftyThink-1.5B/blob/2ffdd84494667fbba35525550f9396492b264e23/README.md （本轮读取的是交接包保存副本）

