# 实际执行代码与 checkpoint 审计（2026-10-22）

范围：已上传的两个交接包，解压于 `/workspace/infty-dev/autodl` 与 `/workspace/infty-dev/handoff/inftythink_codex_handoff`。这是磁盘快照审计，不代表当前 AutoDL 磁盘或本机 `D:\cot` 已经被读取，也没有运行 GPU 推理。

## 1. 可以确认的来源链

已实际重算 SHA256，而非仅引用 README：

| 对象 | SHA256 | 核对结果 |
|---|---|---|
| native20 实际 native_batch_check.py | d0ad25b1029207444748d80956acf85080934dd489a9ecbee58d8051c2c177a6 | 与 run_config、native20 原始 ZIP、AutoDL 快照一致 |
| native20 实际 reference_runner.py | 21ee2ffe505d2316db7aab946d7209af663277cb3a66dfbfac908e2feb19ee32 | 与 run_config、各原始结果 ZIP 一致 |
| 贪心 branch_pilot.py | a6e23f9fd3e6854a41750286fc540cb2d0cbfb39ee9987f2a693f5b6c182cf7b | 与 run_config、原始结果 ZIP 一致 |
| 采样 branch_pilot.py | 97edd04a252d26cde768b8cce020ad401f340f34093aaa6e5cdd9a424f8e5313 | 与 4096 三 seed、5120 配置和原始 ZIP 一致 |
| day1_20.jsonl | 48f689e8b83fa9624e17890163f1c6fb76b8313471e01e5cb566bacf18d7eb35 | 与 native run_config 一致 |

所有 5 组分支配置中的 baseline_config_sha256 与 baseline_cases_sha256 均和 native20 快照实算结果一致。native5 目录实际含 20 个完整诊断记录；实算 26 次调用、98864 个生成 token、6 次已执行摘要重启。记录完成字段不表示推理正确。

以下简称：

- `N=/workspace/infty-dev/autodl/inftythink_official_check/outputs/native5/native_batch_check.py`
- `R=/workspace/infty-dev/autodl/inftythink_official_check/outputs/native5/reference_runner.py`
- `B=/workspace/infty-dev/autodl/inftythink_official_check/outputs/branch4096_sampled/branch_pilot.py`
- `U=/workspace/infty-dev/autodl/inftythink_official_check/upstream/infer_single.py`
- `M=/workspace/infty-dev/autodl/inftythink_day1/models/InftyThink-1.5B`

## 2. checkpoint 与 tokenizer

| 项目 | 已确认事实 | 证据与限制 |
|---|---|---|
| checkpoint 声明 | `yanyc/InftyThink-1.5B@2ffdd84494667fbba35525550f9396492b264e23` | manifest.json:2–3；native run_config 同值；这是 provenance 声明，不是对实际权重字节的校验 |
| 模型卡归属 | 标题和 citation 指向 InftyThink+，同时描述 cold-start SFT 与 RL 两阶段 | M/README.md；模型卡没有明确给出这个 1.5B 文件究竟是哪一阶段的权重。必须进一步用发布清单/权重元数据/论文对应表确认 |
| 架构 | Qwen2ForCausalLM，28 层，12 attention heads，2 KV heads，hidden size 1536，head dim 128 | M/config.json:2–10、45–48；Qwen2 架构本身不能唯一证明训练来源 |
| context 配置 | max_position_embeddings=131072；use_sliding_window=false | M/config.json:43、58；不等于本实验实际使用的预算 |
| tokenizer BOS/EOS | 实际加载得到 BOS=151646，EOS=151643 | M/tokenizer_config.json:30、183–185；实际 AutoTokenizer 加载验证 |
| config BOS | config.json 的 bos_token_id=151643，与 tokenizer BOS 不同 | M/config.json:6；新 HF replay 必须复用保存的 input_token_ids，不能按 config BOS 猜测或重复添加 BOS |
| 控制 token | think 151648/151649；summary 151650/151651；history 151652/151653，均为单 token | 本次加载 tokenizer 实测 |
| 版本 | config 存储 transformers_version=4.57.1；实际历史运行 transformers=4.51.3、vLLM=0.8.5、torch=2.6.0 | 配置记录版本与运行时版本是不同证据。day1/requirements.txt 固定 4.57.1，不能据此升级已经工作的历史 vLLM 环境 |
| 权重可用性 | 上传快照 M 中不存在 safetensors 权重 | 包中故意排除了权重，当前云端不能检验真实生成。AutoDL 现有权重可复用，但需先检查当前文件和 metadata |

## 3. 实际协议与原生示例差异

| 项目 | 官方保存示例 | native20 / A-B-C 实际行为 |
|---|---|---|
| 提示 | `User:{question}Assistant:`（U:3–4、35） | tokenizer chat template，只送 user 题目，然后追加 `<think>\n`（N:46–51）。显式 IDs、add_special_tokens=False、BOS 断言（N:62–67） |
| 最大迭代 | 示例 50 轮（U:7）；示例不是论文完整评测设置 | native20 最大 3 轮，每轮8192，最多可生成24576；A/B 另有限制 total_tokens=16384，包含共享生成前缀，但不包含题目输入 token |
| 采样 | temperature=.7、top_p=.95、单次8192（U:38） | native20 相同；4096 贪心 A/B 为0/1；后续 A/B 为.7/.95；C始终贪心0/1（B:105–115） |
| 摘要解析 | 要求 `</think>` 与 `<summary>` 之间换行（U:18） | 改成允许空白（R:18），其余几个换行结构仍有要求。native20 在调用后核验完整非空 summary 和实际 reset 内容（N:100–114） |
| 重启 | 题目指令＋最新 history | 清除旧详细推理和旧 history，仅保存当前摘要，再加 think；N:106–114，B:159–166、210–213 |
| 失败 | 示例本身诊断较少 | 分别记录 invalid summary/reset、长度截断、segment_limit 等；不可等同错误答案或正常完成 |

必须将“纸面评测协议”“上游单题示例”“本地兼容批处理器”分别列出；当前仅凭同样的 temperature/top_p 不能称为完整复现。

## 4. A/B/C 的干预和成本

候选位置是 native20 第一轮保存的 token 前缀；目标后128 token内第一个段落边界，并且位于推理结束标签之前（B:56–84）。本次直接运行候选选择函数复算：

- 4096：1/4103、6/4203、8/4173、10/4105、11/4100、12/4148、15/4106、19/4096。
- 5120：1/5121、6/5207、8/5189、11/5133、18/5134、19/5157。

筛选不使用答案正确性。候选对象包含 reference_answer，但送入模型的 prefix/base 来自题目与原轨迹；答案字段用于记录。

- **A_continue**：从保存的 prefix_ids 继续，允许随后原生摘要。首调用上限8192-cut（B:194–196）。如果该调用触及长度限制且无完整摘要，函数直接返回 reasoning_token_limit（B:168–170），即便 total budget 还有剩余也不会接着生成。
- **B_summary**：插入 `\n</think><summary>\n`，最多生成1024，stop token来自 tokenizer 的 `</summary>`=151651（B:108、198–213）。摘要成功后从题目＋history重启；强制摘要调用占3个segment之一，因此最多再进行2个 reasoning segment。失败记录 invalid_forced_summary，没有回退到A。这不同于较早 day1.py 的 fallback 逻辑。
- **C_answer**：插入 `\n</think>\nFinal answer: \\boxed{`，贪心最多128 token（B:215–219）；抽取第一闭合 boxed 答案。闭合后未提前停止生成，因此成本应计整次实际输出。
- 共同总生成预算为16384-cut，再减本分支已经生成的token（B:145–151、190）。B插入的控制token单独记录，并作为prefill输入计数；不计为模型生成token。
- 本地A/B预算有明确不对称的“剩余首段长度”和“摘要占segment”限制。后续协议必须公开这些限制，新增公平预算对照不能悄悄修改旧协议并混合结果。
- native seed=`2026+zero_based_case_index*1000+round_index`（N:64）；分支 seed=`seed+case_number*1000+call_index`（B:111），case_number从1开始。相同seed不意味着A复现native轨迹；B的摘要调用也占一个call_index。配对随机seed只是实验设计，不能说不同分支用了相同随机轨迹。
- 每次生成重新prefill；分支engine设置 enable_prefix_caching=False（B:392）。prefill_tokens_total、model_call_seconds可做诊断，但不含共有前缀生成与引擎初始化。表中给A/B追加C token也不能代替实际在线总时间测量。

## 5. 置信度与 attention 的证据

C中每个实际选中token的概率是 `exp(vLLM logprob)`（B:124–130）；找到第一闭合boxed所需token数量（B:227–229）后取其概率的**算术平均**（B:230–232）。范围包括闭合分隔符，也可能包含与该分隔符合并在同一token的后续字符。它不是整答案联合概率或校准后的语义正确率。

本次对4096三seed与5120所有C记录重新求平均，均与保存的probe_confidence吻合。跨seed的C为同一贪心轨迹，不能扩充独立样本数。

B:353写 `attention_entropy_collected=False`。实际保存的调用只含生成IDs、selected-token logprobs和文本等；没有导出attention、hidden states或实现基于H/ΔH/C的触发策略。因此旧实验不能检验联合信号。

## 6. 当前可以直接运行的安全检查

以下用于**原AutoDL目录仍存在**的情况，只做检查，不重新安装依赖、不覆盖历史结果：

```bash
set -euo pipefail
PY=/root/autodl-tmp/venvs/infty-official/bin/python
BASE=/root/autodl-tmp/inftythink_day1
NATIVE=/root/autodl-tmp/inftythink_official_check/outputs/native5
nvidia-smi
"$PY" - <<'PY'
import sys, importlib.metadata, torch
print('python',sys.version)
for name in ('torch','transformers','vllm'):
    print(name,importlib.metadata.version(name))
print('CUDA build',torch.version.cuda,'available',torch.cuda.is_available())
assert torch.cuda.is_available()
print('GPU',torch.cuda.get_device_name(0))
print('BF16',torch.cuda.is_bf16_supported())
assert torch.cuda.is_bf16_supported()
PY
"$PY" "$BASE/day1.py" selftest
"$PY" "$NATIVE/native_batch_check.py" --help
"$PY" /root/autodl-tmp/infty_sampling_check/branch_sampling_check.py --help
```

注意：`day1.py check` 和 `inspect` 会写回其源目录的 `outputs/environment.json`、`outputs/model_audit.json`，本次不建议直接运行，以免覆盖历史审计材料；`report`会写CSV/summary，同样不要指向旧结果。

若需要先确认旧vLLM运行链仍然可工作，以下是现有脚本支持的**可选单题技术检查**。它不是新联合信号实验，也不需要反复重跑旧20题：

```bash
RUN_DIR=$(mktemp -d /root/autodl-tmp/infty_runtime_smoke_XXXXXXXX)
"$PY" "$NATIVE/native_batch_check.py" \
  --model "$BASE/models/InftyThink-1.5B" \
  --data "$BASE/data/day1_20.jsonl" \
  --manifest "$BASE/manifest.json" \
  --reference-runner "$NATIVE/reference_runner.py" \
  --output "$RUN_DIR/native1" \
  --limit 1 --round-tokens 8192 --max-rounds 3 --seed 2026
```

`--reference-runner`必须显式给出：从结果目录调用的脚本默认找邻接的infer_single_checkpoint.py，但该目录保存的是reference_runner.py。native_batch_check严格要求数据集为原20题完整顺序（N:188–189）；不能直接换一个任意2题文件，以为`--limit`能绕过。

命令已按真实CLI/路径审阅；当前云端没有GPU/权重，因此GPU命令仅是待AutoDL执行的命令，不声称已验证。

## 7. 最小上传清单与下一步开发边界

若原AutoDL仍保留上述目录、权重和环境：不需重新上传旧包、论文PDF或3.55GB权重。首轮只需本次新建的preflight/信号采集包与协议说明。静态审计后，本包新增signal_smoke.py并通过7项CPU测试；真实checkpoint的GPU采集尚待AutoDL运行。旧branch_sampling_check本身仍没有entropy开关。

信号最小试跑需读取：固定checkpoint权重/tokenizer/config、native20的run_config/reference_runner及少量cases；新输出须写入新目录。为了原样保留前缀，使用case JSON保存的 input_token_ids 与 generated_token_ids，记录哈希。不要用tokenizer重新encode已解码文本替代这些IDs。

若是新AutoDL实例：需恢复代码/数据/结果快照到独立目录，并重新核对旧配置中的绝对模型路径；当前分支脚本没有 `--model`覆盖参数（B:299–317、333、392），因此不能直接在异路径运行。用新采集器的显式路径参数解决；不要原地改旧run_config。模型需按固定revision获取，真实权重校验成功后才能声称来源闭环。

H采集将涉及Qwen2 GQA的12 query heads/2 KV heads与RoPE/causal mask。选择末层或末query时应先短序列核验与标准attention一致，再扩展至长前缀；不得用词表熵或选中token概率代替attention熵。短答案C可用旧定义作为兼容列，另保留严格按照ASAG定义的列，名称/范围/成本必须明确。
