# ASAG v1 论文审读与本项目的对应关系

审读日期：2026-10-22。这里只报告已读原文和本地代码证据；没有 GPU 实验。

## 材料与身份

- 原论文：`/workspace/infty-dev/handoff/inftythink_codex_handoff/references/uploaded_papers/2606.15070v1(2).pdf`，22 页。PDF 第 1 页明确标示 **arXiv:2606.15070v1 [cs.CL], 13 Jun 2026**。
- 标题：*Stop When Further Reasoning Won't Help: Attention-State Adaptive Generation in Reasoning Models*；Jiakai Li 等。
- PDF SHA256：`6da712f8f7c35c1c95df2dd39f0a71a0e8e66481d5eecdb6e4be48c60510d322`。
- 同目录 `ASAG(1).pdf` 是中文解读材料，不能替代上述原论文作为方法定义的依据。
- 原文 URL：<https://arxiv.org/abs/2606.15070v1>；本文引用页码均为 PDF 印刷页码。
- 已提取全文至 `asag.txt`；已渲染并目视检查第 3 页，确认式 (2) 的分母确实只有 `log k`，没有除以 query 数 q。

## 核心定义：可以从原文直接确认

1. **attention 权重**：式 (1)，第 3 页：`A^W_{h,l}=Softmax(A^S_{h,l}, dim=-1)`。沿 key 维归一化，不能用词表输出熵替代。
2. **单头、单层 entropy**：式 (2)，第 3 页：

   `H_{h,l}= - sum_{i=1..q} sum_{j=1..k} A[i,j] log A[i,j] / log(k)`。

   i 是选定 query 窗口，j 是全局 key；式中对 q 个 query 求和，不求均值。对于固定 q，除不除 q 在相对变化率中可抵消，但跨不同 q、模型、模板直接比较原始 H 会有混淆。q 和 k 必须保存。

3. **层、头聚合**：式 (3)/(6)，第 3/4 页：最后四层、所有 attention heads 求和。对于当前本地 Qwen2 配置（28 层、12 attention heads、2 KV heads），应为零基索引 24–27 的 12 个 query attention heads；不能把 2 个 KV heads 当成 N。
4. **方法阶段的 query 窗口**：第 4 页末至第 5 页，含 probing prompt I 的所有 token，外加同等数量最近的 thought tokens。若 I 有 m 个 token，则 q=2m，位于 `T_tail + I`；query 不是全部历史，也不是 probe 答案 token。
5. **研究观察阶段的窗口**：附录 A，第 13 页明确 Section 3 用 window length 32。它与 Section 4 的 `2*len(tokenize(I))` 规则不能未经说明混为一谈。当前本地 tokenizer 把精确字符串 `\n\n Final Answer\n\n \\boxed` 编为 **6 tokens**，因此按 Section 4 字面规则为 12 query tokens。该 tokenizer 编码已在 CPU 实测。
6. **变化率基点**：Section 4.1 第 5 页、Algorithm 1 第 13 页和附录 G 第 17 页均使用 `ΔH=(H_current-H_first_ATP)/H_first_ATP`。不是相邻两个监测点之差，也不是滑动平均斜率。Section 3 的观察分析使用了不同时间点对比，不应据此改写在线算法基点。
7. **probe 与置信度**：第 4 页式 (5)：在 ATP 附加 `I="\n\n Final Answer\n\n \\boxed"`；生成 intermediate answer A；C 是生成的答案 token 所选概率的**算术均值**。不是平均 logprob、几何均值或序列联合概率。
8. **ATP**：主实验使用 “Wait”；第 9 页 Table 4 比较 “Alternatively”。段落边界 `\n\n` 不是论文主实验 ATP。具体大小写、空格、token-id 匹配方式未从 PDF 得到完整实现定义。

## ASAG 实际做哪些动作

原文第 4–5 页 / Algorithm 1 第 13 页有四种分支，并非只有 early exit：

| 状态 | ASAG 动作 | 证据 |
|---|---|---|
| 第一个 ATP，C > λ | 插入 `</think>`，进入答案生成 | §4.1、Algorithm 1 |
| 后续 ATP，C > λ 且 ΔH < α | 插入 `</think>`，结束推理阶段 | §4.1 |
| C < λ 且 ΔH < α | 以 0.95/0.05 混合当前输出概率与中间答案的概率分布，引导后续生成 | §4.2，式 (7) |
| ΔH > α 且前一个 thought 的平均 token attention 大于当前 thought | 加 jump prompt；达到上限后结束推理 | §4.3，式 (8) |
| 其他情况 | 正常继续 | 方法描述 |

其中式 (7) 名称虽为 logits injection，表达式实际写的是 `0.95*Softmax(M(P,T)) + 0.05*Logits_r`；`Logits_r` 也被描述为归一化概率。不能擅自当作未经 softmax 的 logits 相加。

jump prompt 原文为：`Wait, my previous reasoning is not correct. I should adopt a more concise and different approach to reexamine this problem.\n\n`。这是向现有上下文追加提示，不是生成可保存摘要、丢弃旧历史并重建上下文。原文的 early exit 插入 delimiter，伪代码并非直接把 probe A 交给用户。

## 实验设置与效率边界

- §5.1 第 6 页：BF16；`do_sample=False, temperature=0, top_p=1, max_new_tokens=16000`；`λ=0.95, α=-0.1, s=1`。
- §5.4 第 8 页另有采样验证：temperature=0.6、top_p=0.95、每题 3 次采样。当前已有分支实验 temperature=0.7，不能称为该设置复现。
- Appendix D.2 第 15 页：zero-shot 指令为 `Please reason step by step, and put your final answer within \\boxed.`；Python 3.10、PyTorch 2.6.0、CUDA 12.1；总体硬件 8× A800。
- §5.5 第 8–9 页：端到端延迟在单张 A800 80 GB 上测；论文报告 probe 小于总时间 10%，Qwen3-8B 约 1.51× 加速。该数字不能直接迁移到 RTX4090、1.5B 或 offline replay。
- 正文指标 Len/CR 只定义为 generated-token 长度，没有充分细分 probe tokens 是否如何累计，仍需实际实现核对；本项目应独立记录所有探测解码和 prefill 成本。

## PDF 尚不足以唯一复现的细节与内部不一致

这些是复现需澄清项，不是方法失败证据：

- probe 答案的最大长度、结束条件、是否包含 boxed 分隔符/EOS、多 token 答案概率提取的确切范围，没有在已读方法/附录中完整规定。当前代码 C 分支显式加 `</think>`、`Final answer:` 和 `{`，并将闭合答案盒的 delimiter 纳入均值，与 ASAG 精确 prompt 不同，需新版本记录。
- Eq (2) 的因果 mask、不同 query 可见 key 数处理、是否用统一矩阵 k 或每行有效 key 数做归一化没有具体实现说明。字面公式是统一 `log k`；若按每行 key 数归一化，应注明为另一定义。
- §4.1 明确方法窗口为 I+最近等长 thought，Appendix A 的 32 属于观察实验。应分别实现/命名，不偷换。
- 第 8 页 “Effect of injecting Logits_r” 写 C>λ，但 §4.2 和 Algorithm 1 写 C<λ。应以方法定义和伪代码一致部分为主，并在复现记录中标出此处文字矛盾。
- Algorithm 1 使用 `jump_count <= s` 再递增，初始化 0、s=1 会允许两次；正文称 maximum jump attempts s。不能静默把任一解释称为唯一官方行为。
- 伪代码的边界 `C==λ`、`ΔH==α` 和 first ATP 低置信度的 fallback 不完整；`Logits_r` 如何从多 token A 聚合、保持多久也不够清楚。
- 本地原论文 PDF 未提供可直接定位的 GitHub 代码链接；此审读没有核验作者实现，不能宣称严格代码级复现。
- 附录 I 将单头局部 attention 稳定性与全模型/推理的全局收敛联系起来，但不足以保证答案正确或摘要可保真。其假设不覆盖实际残差、K/V 状态变化及语义正确性，不能作为本 idea 的证明。

## 对本项目的判断与最小验证建议

1. 训练免费的 H/ΔH+C 联合状态判断已由 ASAG 提出；潜在增量在**选择“摘要压缩后继续”这个动作**、收益机制和完整成本，而非两个信号本身。
2. ASAG 把低 ΔH+高 C 看作可结束推理；直接把同一条件改成“摘要后继续”可能只增加成本。必须区分“可直接交付答案”与“尚需推理、但进展可压缩”，并与同模型的 ASAG式早停比较。
3. 模型自身（尤其 InftyThink+）已有摘要时机策略，强基线应为其原生可摘要策略。继续分支不应被误称为永不摘要。
4. 第一次 GPU 检查宜只做少量已保存前缀的测量：短序列下与完整 eager attention 参考实现逐头/逐层核对；长序列仅重算末端 query 的 attention 行，避免全序列 L×H×T² 保存。对于 GQA 必须正确展开 KV heads，并使用正确 RoPE、位置、mask。
5. offline replay 能验证信号数值和关联，不能证明在线加速；重放成本要单列，后续端到端实验必须计入 probe、摘要、重置 prefill 和监测开销。
6. 每个样本至少保存：模型/代码 revision、tokenizer hash、prefix token IDs/hash、ATP 类型和 token offset、I 的完整 token IDs、q/k、各层/头 H、聚合 H、H_first、ΔH、probe tokens 和逐 token 概率、C、峰值显存、每部分耗时。阈值仅在开发集校准。
7. 第一轮不把 α=-0.1、λ=0.95 定为最终阈值；可将原文值作为预先声明的迁移基线。先看可重复性、长度混淆和动作收益，再判断是否值得扩大。
8. **顶会潜力初判：值得低成本检验，但目前创新与效果证据均不足。** 需要证明联合信号在长度/阶段之外识别摘要的条件性净收益，效果超过原生策略、固定/随机位置、C-only、H-only 和 early-exit 替代，并在至少另一个模型/任务上泛化。几个正确例子或少量 token 下降不足以支持顶会结论。
