# Offline signal smoke v1

This is a measurement diagnostic, not an online controller or an exact ASAG reproduction.

- Reuses native20's saved input/generated token IDs without prompt reconstruction. Tokenizer BOS is checked; model config BOS is not substituted.
- Reads original files and creates a new output directory. Existing directories are rejected, even if empty. No checkpoint download or environment installation is performed.
- Eager Qwen2 attention prefill is chunked (default 128 queries). Only the final 32 prefix queries request retained attention tensors; entropy aggregates the last four layers and all heads. No full sequence square attention matrix is retained/exported.
- Normalization uses the complete key length, while causal future entries are zero. It saves both the query-summed and query-mean result. HF 4.51.3 computes eager softmax in FP32 and casts probabilities to model dtype; entropy is reduced in FP32 after that cast. Row mass error is recorded.
- The diagnostic window is raw reasoning-tail tokens. ASAG's online window includes the probing instruction plus an equally sized preceding reasoning segment. These definitions differ.
- Relative change is from the first requested valid diagnostic cut per case. It is not ASAG's first-ATP reference and cannot inherit ASAG's thresholds.
- Optional C is an independent greedy boxed-answer probe, using the historical suffix and arithmetic mean selected-token probabilities. It stops at the first balanced closing brace, unlike the historical fixed-budget C, so cost is a new protocol. Truncated/unclosed answers have C=null. Empty closed boxes require manual review. C is not a calibrated semantic correctness probability.
- Probe token budget defaults to 32 for interface/cost testing; it does not match the previous 128-token probe budget. A separate new run may use 128 after inspection. Do not mix protocols.
- Timings include replay and probe prefill costs, but exclude original trajectory generation and checkpoint loading (loading is recorded separately). They are not end-to-end speedup estimates.
- CPU tests use a tiny random Qwen2, not the research checkpoint. Actual GPU/checkpoint operation must be measured on AutoDL before expanding the experiment.
- Optional --check-short-reference compares prefixes of at most 512 total tokens with full eager attention in the actual dtype/device, and reports H/logit differences and next-token agreement. Larger prefixes are explicitly skipped. Its time is recorded separately; peak GPU memory for that run includes the reference check. This bounded diagnostic is the sole full-matrix exception.

Example (existing AutoDL environment):

```bash
/root/autodl-tmp/venvs/infty-official/bin/python signal_smoke.py \
  --model /root/autodl-tmp/inftythink_day1/models/InftyThink-1.5B \
  --baseline /root/autodl-tmp/inftythink_official_check/outputs/native5 \
  --cases 1,6 --cuts 128,256 --query-window 32 --prefill-chunk 128 \
  --probe-tokens 32 --output /root/autodl-tmp/infty_signal_runs/smoke_001
```

First run the preflight provided alongside this script and ensure no other vLLM process occupies the GPU. If smoke_001 already exists, choose a new output directory. The first successful run should contain summary.json with completed=true and executed_positions=4 (unless a prefix had already stopped thinking); every measured record includes finite H, probability metadata, time, and GPU memory. A completed record is not an accuracy result. A successful smoke test establishes measurement availability, not the value of summary timing.

For exact pairing with existing branch runs, replace --cases/--cuts with --candidates PATH/candidates.json [PATH2/candidates.json ...]. The script uses selected natural-boundary case/cut pairs and verifies every prefix token against the original saved trajectory. It refuses mismatches. Select small candidate batches first; multiple files can cover several target lengths without changing old results. This preserves each branch's actual cut, rather than treating the requested target as its exact position.
