#!/usr/bin/env python3
"""Read-only audit of an existing AutoDL checkout; all new files go to --output."""
import argparse
import hashlib
import importlib.metadata
import json
from pathlib import Path
import platform
import subprocess
import sys

MODEL_REV = '2ffdd84494667fbba35525550f9396492b264e23'
DATA_REV = '6e4ed1a2a79af7d8630a6b768ec859cb5af4d3be'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, default=Path('/root/autodl-tmp'))
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--require-gpu', action='store_true')
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=False)
    report = {'root': str(args.root.resolve()), 'python': sys.version,
              'executable': sys.executable, 'platform': platform.platform(),
              'errors': [], 'gpu_blockers': [], 'warnings': [], 'checks': {}}

    def check(name, fn):
        try:
            value = fn()
            report['checks'][name] = value
        except Exception as exc:
            report['errors'].append({'check': name, 'error': str(exc)})

    day1 = args.root / 'inftythink_day1'
    baseline = args.root / 'inftythink_official_check/outputs/native5'
    model = day1 / 'models/InftyThink-1.5B'

    def audit_sources():
        cfg = json.loads((baseline / 'run_config.json').read_text())
        assert cfg['model_revision'] == MODEL_REV, 'baseline revision mismatch'
        assert cfg['dataset_revision'] == DATA_REV, 'dataset revision mismatch'
        pairs = [('native_batch_check.py', 'script_sha256'),
                 ('reference_runner.py', 'reference_runner_sha256')]
        hashes = {name: sha(baseline / name) for name, _ in pairs}
        for name, key in pairs:
            assert hashes[name] == cfg[key], f'{name} differs from executed version'
        data_hash = sha(day1 / 'data/day1_20.jsonl')
        assert data_hash == cfg['data_sha256'], 'day1_20 checksum mismatch'
        case_paths = sorted((baseline / 'cases').glob('*.json'))
        records = [json.loads(p.read_text()) for p in case_paths]
        assert [r['case'] for r in records] == list(range(1, 21)), 'native20 case set mismatch'
        manifest = json.loads((day1 / 'manifest.json').read_text())
        assert [r['unique_id'] for r in records] == manifest['day1_ids'], 'native20 ID order differs from manifest'
        assert all(r.get('completed') for r in records), 'incomplete native records'
        assert all(r['rounds'][0]['input_token_ids'] and r['rounds'][0]['generated_token_ids'] for r in records)
        return {'model_revision_claim_in_config': cfg['model_revision'],
                'script_hashes': hashes, 'data_sha256': data_hash,
                'baseline_config_sha256': sha(baseline / 'run_config.json'),
                'case_collection_sha256': hashlib.sha256(''.join(sha(p) for p in case_paths).encode()).hexdigest(),
                'native_cases': len(records)}

    def audit_splits():
        manifest = json.loads((day1 / 'manifest.json').read_text())
        assert manifest['model_revision'] == MODEL_REV
        assert manifest['dataset_revision'] == DATA_REV
        ids = []
        for name, n in [('dev80', 80), ('test120', 120), ('reserve300', 300)]:
            rows = [json.loads(s) for s in (day1 / f'data/{name}.jsonl').read_text().splitlines() if s.strip()]
            current = [r['unique_id'] for r in rows]
            assert len(current) == n and current == manifest['split_ids'][name]
            ids.extend(current)
        assert len(set(ids)) == 500, 'overlap in data splits'
        day1_rows = [json.loads(s) for s in (day1 / 'data/day1_20.jsonl').read_text().splitlines() if s.strip()]
        dev_rows = [json.loads(s) for s in (day1 / 'data/dev80.jsonl').read_text().splitlines() if s.strip()]
        assert day1_rows == dev_rows[:20], 'day1_20 differs from dev80 first 20'
        assert [r['unique_id'] for r in day1_rows] == manifest['day1_ids'], 'day1 IDs differ from manifest'
        return {'total_unique': 500, 'split_sizes': [80, 120, 300],
                'manifest_sha256': sha(day1 / 'manifest.json')}

    def audit_tokenizer():
        from transformers import AutoTokenizer
        tok = AutoTokenizer.from_pretrained(model, local_files_only=True)
        cfg = json.loads((model / 'config.json').read_text())
        markers = {s: tok.encode(s, add_special_tokens=False) for s in
                   ['<think>', '</think>', '<summary>', '</summary>', '<history>', '</history>']}
        assert all(len(v) == 1 for v in markers.values())
        record = json.loads((baseline / 'cases/001.json').read_text())
        first = record['rounds'][0]
        prompt = tok.apply_chat_template([{'role': 'user', 'content': record['problem']}],
                                        tokenize=False, add_generation_prompt=True) + '<think>\n'
        assert prompt == first['prompt'], 'current tokenizer prompt differs from native20'
        assert tok.encode(prompt, add_special_tokens=False) == first['input_token_ids'], 'prompt token IDs changed'
        weights = sorted(model.glob('*.safetensors'))
        weight_info = {'count': len(weights), 'bytes': sum(p.stat().st_size for p in weights),
                       'revision_verified_from_weight_contents': False}
        if not weights:
            report['gpu_blockers'].append('No local safetensors model weights')
        index = model / 'model.safetensors.index.json'
        if index.exists():
            files = set(json.loads(index.read_text())['weight_map'].values())
            missing = [name for name in files if not (model / name).is_file()]
            if missing:
                report['gpu_blockers'].append('Missing shards: ' + ', '.join(missing))
        return {'model_type': cfg['model_type'], 'layers': cfg['num_hidden_layers'],
                'heads': cfg['num_attention_heads'], 'kv_heads': cfg['num_key_value_heads'],
                'config_bos': cfg.get('bos_token_id'), 'tokenizer_bos': tok.bos_token_id,
                'tokenizer_eos': tok.eos_token_id, 'marker_ids': markers,
                'saved_prompt_ids_match': True, 'weights': weight_info}

    for name, fn in [('sources', audit_sources), ('splits', audit_splits), ('tokenizer', audit_tokenizer)]:
        check(name, fn)
    packages = {}
    for name in ['torch', 'transformers', 'vllm', 'huggingface_hub']:
        try:
            packages[name] = importlib.metadata.version(name)
        except importlib.metadata.PackageNotFoundError:
            packages[name] = None
    report['packages'] = packages
    for name, expected in [('torch', '2.6.0'), ('transformers', '4.51.3'), ('vllm', '0.8.5')]:
        actual = packages[name]
        if not actual or actual.split('+')[0] != expected:
            report['gpu_blockers'].append(f'{name}: expected {expected}, found {actual}')
    try:
        import torch
        cuda = torch.cuda.is_available()
        report['cuda'] = {'available': cuda, 'build': torch.version.cuda}
        if cuda:
            report['cuda'].update(name=torch.cuda.get_device_name(0),
                                  total_bytes=torch.cuda.get_device_properties(0).total_memory,
                                  bf16_supported=torch.cuda.is_bf16_supported())
            if not torch.cuda.is_bf16_supported():
                report['gpu_blockers'].append('GPU has no supported BF16')
        else:
            report['gpu_blockers'].append('CUDA unavailable')
    except Exception as exc:
        report['gpu_blockers'].append(f'torch/CUDA check failed: {exc}')
    try:
        result = subprocess.run([sys.executable, str(day1 / 'day1.py'), 'selftest'],
                                capture_output=True, text=True, check=False)
        (args.output / 'selftest.log').write_text(result.stdout + result.stderr)
        if result.returncode:
            report['errors'].append({'check': 'day1_selftest', 'exit_code': result.returncode})
        report['checks']['selftest_exit_code'] = result.returncode
    except Exception as exc:
        report['errors'].append({'check': 'day1_selftest', 'error': str(exc)})
    report['warnings'].append('Model card/manifest claims do not verify local weight provenance or paper-table mapping.')
    report['audit_ok'] = not report['errors']
    report['gpu_prerequisites_ok'] = not report['errors'] and not report['gpu_blockers']
    (args.output / 'preflight.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps(report, ensure_ascii=False, indent=2))
    return int(bool(report['errors'] or (args.require_gpu and report['gpu_blockers'])))


if __name__ == '__main__':
    raise SystemExit(main())
