#!/usr/bin/env python3
"""No weights/network needed: mathematical and tiny-Qwen2 consistency checks."""
import unittest
from types import SimpleNamespace

import torch
from transformers import Qwen2Config, Qwen2ForCausalLM

from signal_smoke import attention_summary, closed_box, replay_attention, build_prefix, probe_answer, verify_candidate, short_reference_comparison


class SignalChecks(unittest.TestCase):
    def test_uniform_attention_normalization(self):
        a = torch.full((1, 2, 3, 7), 1 / 7)
        r = attention_summary((a,) * 4)
        self.assertAlmostEqual(r["H_sum_over_layers_heads_queries_div_log_keys"], 24, places=5)
        self.assertAlmostEqual(r["H_query_mean_sum_over_layers_heads_div_log_keys"], 8, places=5)
        self.assertAlmostEqual(r["H_mean_over_layers_heads_queries_div_log_keys"], 1, places=5)

    def test_point_mass_zero_entropy(self):
        a = torch.zeros((1, 2, 3, 7)); a[..., 0] = 1
        self.assertEqual(attention_summary((a,) * 4)["entropy_sum_nats"], 0)

    def test_box_closure_nested_and_truncated(self):
        self.assertEqual(closed_box(r"\boxed{\frac{1}{2}} trailing"), (r"\frac{1}{2}", 19))
        self.assertIsNone(closed_box(r"\boxed{\frac{1}{2}"))
        self.assertEqual(closed_box(r"\boxed{4}\boxed{6}")[0], "4")

    def test_saved_prefix_excludes_answers_and_rejects_end(self):
        class Tok:
            bos_token_id = 1
            eos_token_id = 9
            def convert_tokens_to_ids(self, t):
                return {"</think>": 6, "<summary>": 7, "</summary>": 8}[t]
        r = {"reference_answer": "SECRET", "rounds": [{"input_token_ids": [1, 2], "generated_token_ids": [3, 4, 6, 5]}]}
        self.assertEqual(build_prefix(r, 2, Tok()), ([1, 2, 3, 4], None))
        self.assertIsNone(build_prefix(r, 3, Tok())[0])
        self.assertIsNone(build_prefix(r, 5, Tok())[0])

    def test_probe_probability_closure_and_truncation(self):
        class Tok:
            eos_token_id = 9
            def encode(self, text, **kwargs):
                return [7, 8]
            def decode(self, ids, **kwargs):
                return "".join({3: r"\frac{", 4: "1}{2}", 5: "}"}[i] for i in ids)
        class Model:
            def __init__(self):
                self.input_lengths = []
            def __call__(self, input_ids, past_key_values, **kwargs):
                length = (past_key_values or 0) + input_ids.shape[1]
                self.input_lengths.append(length)
                target = [3, 4, 5][max(0, min(2, length - 4))]
                logits = torch.zeros(1, 1, 10)
                logits[0, 0, target] = torch.log(torch.tensor(9.0))
                return SimpleNamespace(past_key_values=length, logits=logits)
        model = Model()
        result = probe_answer(model, Tok(), [1, 2], 10, 3, "cpu")
        self.assertEqual(result["generated_token_ids"], [3, 4, 5])
        self.assertEqual(result["answer"], r"\frac{1}{2}")
        self.assertEqual(result["status"], "closed_box_review_required")
        self.assertAlmostEqual(result["confidence_mean_selected_token_probability"], .5, places=6)
        self.assertEqual(model.input_lengths, [3, 4, 5, 6])
        truncated = probe_answer(Model(), Tok(), [1, 2], 2, 3, "cpu")
        self.assertEqual(truncated["status"], "token_limit_without_closed_box")
        self.assertIsNone(truncated["confidence_mean_selected_token_probability"])
        self.assertIsNone(truncated["answer"])

    def test_candidate_pairing_rejects_prefix_and_identity_mismatch(self):
        candidate = {"case": 1, "cut": 2, "unique_id": "one", "prefix_token_ids": [1, 2, 3]}
        record = {"case": 1, "unique_id": "one", "reference_answer": "SECRET"}
        verify_candidate(candidate, record, [1, 2, 3], None)
        for bad_ids, bad_record, reason in [([1, 2, 4], record, None),
                ([1, 2, 3], {"case": 1, "unique_id": "other"}, None),
                (None, record, "thinking_already_ended_at_or_before_cut")]:
            with self.subTest(reason=reason, ids=bad_ids), self.assertRaises(ValueError):
                verify_candidate(candidate, bad_record, bad_ids, reason)

    def test_chunked_attention_and_logits_match_full_forward(self):
        torch.manual_seed(2026)
        torch.set_num_threads(1)
        cfg = Qwen2Config(vocab_size=97, hidden_size=32, intermediate_size=48,
                          num_hidden_layers=4, num_attention_heads=4,
                          num_key_value_heads=2, max_position_embeddings=128,
                          attention_dropout=0, use_sliding_window=False, sliding_window=None)
        cfg._attn_implementation = "eager"
        model = Qwen2ForCausalLM(cfg).eval()
        ids = [1, 12, 23, 34, 45, 56, 67, 78, 2, 9, 10]
        with torch.inference_mode():
            full = model(torch.tensor([ids]), use_cache=False, output_attentions=True, logits_to_keep=1)
        reference = attention_summary(tuple(a[:, :, -3:, :] for a in full.attentions))
        for chunk in (1, 2, 5, 128):
            with self.subTest(chunk=chunk):
                actual, logits = replay_attention(model, ids, 3, chunk, "cpu")
                self.assertAlmostEqual(actual["entropy_sum_nats"], reference["entropy_sum_nats"], places=4)
                torch.testing.assert_close(logits, full.logits[:, -1, :], rtol=1e-5, atol=1e-6)
                comparison = short_reference_comparison(model, ids, 3, actual, logits, "cpu")
                self.assertLess(comparison["H_relative_difference"], 1e-5)
                self.assertLess(comparison["logit_max_absolute_difference"], 1e-5)
                self.assertTrue(comparison["greedy_next_token_agrees"])


if __name__ == "__main__":
    unittest.main(verbosity=2)
