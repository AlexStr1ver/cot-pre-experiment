#!/usr/bin/env bash
# Same questions, multiple exact saved prefixes. Measurement only, no policy actions.
set -euo pipefail
ROOT=${1:-/root/autodl-tmp}
LIMIT=${2:-3}
PKG=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
PY="$ROOT/venvs/infty-official/bin/python"
MODEL="$ROOT/inftythink_day1/models/InftyThink-1.5B"
NATIVE="$ROOT/inftythink_official_check/outputs/native5"
EXP=$(mktemp -d "$ROOT/infty_signal_phase2_XXXXXXXX")
printf 'OUTPUT_DIRECTORY=%s\n' "$EXP"

finish() {
    local task_exit=$?
    printf '%s\n' "$task_exit" > "$EXP/exit_status.txt"
    if [ -x "$PY" ]; then
        "$PY" - "$EXP" <<'PY'
import pathlib, sys, zipfile
p = pathlib.Path(sys.argv[1]).resolve()
out = p.parent / (p.name + '_return.zip')
with zipfile.ZipFile(out, 'x', compression=zipfile.ZIP_DEFLATED) as z:
    for f in sorted(p.rglob('*')):
        if f.is_file():
            z.write(f, f.relative_to(p))
print('RETURN_ZIP=' + str(out))
PY
    fi
    return "$task_exit"
}
trap finish EXIT

cd "$PKG"
sha256sum -c checksums.sha256 2>&1 | tee "$EXP/package_checksums.log"
test -x "$PY"
mkdir "$EXP/code"
cp -- prepare_plan.py collect_phase2.py v1_core.py test_prepare_plan.py test_collect_phase2.py run_phase2.sh "$EXP/code/"
"$PY" test_prepare_plan.py 2>&1 | tee "$EXP/plan_tests.log"
"$PY" test_collect_phase2.py 2>&1 | tee "$EXP/collector_tests.log"
"$PY" prepare_plan.py --model "$MODEL" --baseline "$NATIVE" \
    --limit "$LIMIT" --targets 1024,2048,4096 --boundary-window 128 \
    --output "$EXP/plan.json" 2>&1 | tee "$EXP/plan.log"
"$PY" collect_phase2.py --model "$MODEL" --baseline "$NATIVE" \
    --plan "$EXP/plan.json" --output "$EXP/signals" --device cuda \
    --probe-tokens 128 --prefill-chunk 128 --canary-chunk 64 \
    2>&1 | tee "$EXP/signals.log"
